# Tarot Reina - TODO

## Fase 1: Base de datos y datos
- [x] Esquema de base de datos (tarotistas, reservas, reseñas, bonos, chats)
- [x] Datos de los 45 tarotistas IA con perfiles, especialidades y disponibilidad
- [x] Migración de base de datos

## Fase 2: Tema y layout
- [x] Tema oscuro místico negro y dorado en index.css
- [x] Logo de corona dorada (SVG en Navbar)
- [x] Tipografía elegante (Cinzel, EB Garamond, Raleway via Google Fonts)
- [x] Navbar principal con navegación
- [x] Footer con datos de contacto
- [x] Layout general de la aplicación

## Fase 3: Páginas principales
- [x] Página de inicio (hero, características, tarotistas destacadas, CTA)
- [x] Página de listado de 45 tarotistas con filtros
- [x] Página de perfil individual de tarotista
- [ ] Página "Sobre nosotros" (pendiente para futura iteración)

## Fase 4: Chat IA y chatbot Luna
- [x] Chat IA en tiempo real para consultas de tarot
- [x] Historial de conversaciones por usuario
- [x] Chatbot Luna como asistente virtual flotante
- [x] Procedimientos tRPC para chat IA

## Fase 5: Reservas y autenticación
- [x] Formulario de reservas con selección de tarotista, fecha y hora
- [x] Gestión de citas (crear, ver, cancelar)
- [x] Autenticación de usuarios con OAuth
- [x] Perfiles de usuario con historial de consultas

## Fase 6: Reseñas y bonos
- [x] Sistema de reseñas y valoraciones (1-5 estrellas)
- [x] Mostrar reseñas en perfiles de tarotistas
- [x] Sistema de bonos y paquetes de consultas
- [ ] Integración de pagos con Stripe (pendiente configuración de claves)
- [x] Gestión de bonos activos por usuario

## Fase 7: Panel de administración
- [x] Dashboard admin con estadísticas
- [x] Gestión de tarotistas (activar/desactivar/destacar)
- [x] Gestión de reservas (confirmar/cancelar/completar)
- [x] Gestión de usuarios
- [x] Gestión de contenido y reseñas (moderación)

## Fase 8: Detalles finales
- [x] Botón flotante de WhatsApp (+34 625815306)
- [x] Notificaciones al propietario (sistema de notificaciones disponible)
- [x] Tests vitest (16/16 pasando)
- [x] Checkpoint final y publicación

## Actualización v2
- [x] Subir logo oficial (LOGOTAROTREINA.png) a S3 y usarlo en Navbar y favicon
- [x] Subir foto de la Reina (FOTOREINA.jpg) a S3 y mostrarla como tarotista destacada
- [x] Integrar Stripe para pagos reales de bonos con checkout session
- [x] Añadir página "Sobre Nosotras" con historia y valores
- [x] Personalizar tarotista "La Reina" con foto real y bio destacada en Home

## Actualización v3
- [x] Fotos reales de tarotistas copiadas de Tarot Meiga (43 tarotistas actualizadas)
- [x] Integrar fotos en listado de tarotistas, perfil individual, home y consulta IA
