import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Tarotistas from "./pages/Tarotistas";
import TarotistaProfile from "./pages/TarotistaProfile";
import Consulta from "./pages/Consulta";
import Reservas from "./pages/Reservas";
import Bonos from "./pages/Bonos";
import Perfil from "./pages/Perfil";
import Admin from "./pages/Admin";
import SobreNosotras from "./pages/SobreNosotras";
import ChatbotLuna from "./components/ChatbotLuna";
import WhatsAppButton from "./components/WhatsAppButton";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/tarotistas" component={Tarotistas} />
      <Route path="/tarotistas/:slug" component={TarotistaProfile} />
      <Route path="/consulta" component={Consulta} />
      <Route path="/consulta/:tarotistaId" component={Consulta} />
      <Route path="/reservas" component={Reservas} />
      <Route path="/bonos" component={Bonos} />
      <Route path="/perfil" component={Perfil} />
      <Route path="/admin" component={Admin} />
      <Route path="/sobre-nosotras" component={SobreNosotras} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function Layout() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Navbar />
      <main className="flex-1 pt-16">
        <Router />
      </main>
      <Footer />
      <ChatbotLuna />
      <WhatsAppButton />
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            toastOptions={{
              style: {
                background: "oklch(0.11 0.008 285)",
                border: "1px solid oklch(0.78 0.14 85 / 0.3)",
                color: "oklch(0.95 0.02 85)",
              },
            }}
          />
          <Layout />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
