import { Link } from "wouter";
import { Crown, Mail, Phone, Instagram, Facebook, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[oklch(0.05_0.003_285)] border-t border-[oklch(0.78_0.14_85/0.2)] mt-20">
      {/* Divider dorado */}
      <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.14_85/0.6)] to-transparent" />

      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Logo y descripción */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Crown className="w-7 h-7" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
              <div className="flex flex-col leading-none">
                <span
                  className="text-base font-bold tracking-widest"
                  style={{
                    fontFamily: "'Cinzel Decorative', serif",
                    background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  TAROT
                </span>
                <span
                  className="text-xs tracking-[0.4em] uppercase"
                  style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}
                >
                  REINA
                </span>
              </div>
            </Link>
            <p className="text-sm text-[oklch(0.60_0.04_85)] leading-relaxed font-garamond italic">
              Sabiduría ancestral del tarot, potenciada por inteligencia artificial. 
              Guía espiritual disponible las 24 horas.
            </p>
            <div className="flex gap-3 mt-5">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-full border border-[oklch(0.78_0.14_85/0.3)] flex items-center justify-center text-[oklch(0.78_0.14_85/0.6)] hover:text-[oklch(0.78_0.14_85)] hover:border-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] transition-all duration-200"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Navegación */}
          <div>
            <h4
              className="text-xs tracking-[0.3em] uppercase mb-5 font-semibold"
              style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}
            >
              Navegación
            </h4>
            <ul className="space-y-3">
              {[
                { href: "/", label: "Inicio" },
                { href: "/tarotistas", label: "Nuestras Tarotistas" },
                { href: "/consulta", label: "Consulta IA" },
                { href: "/reservas", label: "Reservas" },
                { href: "/bonos", label: "Bonos y Paquetes" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-[oklch(0.60_0.04_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors"
                    style={{ fontFamily: "'Raleway', sans-serif" }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Servicios */}
          <div>
            <h4
              className="text-xs tracking-[0.3em] uppercase mb-5 font-semibold"
              style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}
            >
              Especialidades
            </h4>
            <ul className="space-y-3">
              {[
                "Amor y Relaciones",
                "Trabajo y Dinero",
                "Espiritualidad",
                "Decisiones Importantes",
                "Vidas Pasadas",
                "Predicciones",
              ].map((item) => (
                <li key={item}>
                  <span
                    className="text-sm text-[oklch(0.60_0.04_85)]"
                    style={{ fontFamily: "'Raleway', sans-serif" }}
                  >
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contacto */}
          <div>
            <h4
              className="text-xs tracking-[0.3em] uppercase mb-5 font-semibold"
              style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}
            >
              Contacto
            </h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 shrink-0" style={{ color: "oklch(0.78 0.14 85)" }} />
                <a
                  href="mailto:reinatarot78@gmail.com"
                  className="text-sm text-[oklch(0.60_0.04_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors"
                >
                  reinatarot78@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 shrink-0" style={{ color: "oklch(0.78 0.14 85)" }} />
                <a
                  href="https://wa.me/34625815306"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-[oklch(0.60_0.04_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors"
                >
                  +34 625 815 306
                </a>
              </li>
            </ul>
            <div
              className="mt-6 p-4 rounded-lg border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.11_0.008_285)]"
            >
              <p
                className="text-xs text-[oklch(0.78_0.14_85)] font-semibold mb-1"
                style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}
              >
                Disponible 24/7
              </p>
              <p className="text-xs text-[oklch(0.60_0.04_85)]">
                Nuestras 45 tarotistas IA están siempre disponibles para guiarte.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-[oklch(0.78_0.14_85/0.1)] py-5">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-3">
          <p
            className="text-xs text-[oklch(0.45_0.03_85)]"
            style={{ fontFamily: "'Raleway', sans-serif" }}
          >
            © {new Date().getFullYear()} Tarot Reina. Todos los derechos reservados.
          </p>
          <div className="flex gap-5">
            {["Privacidad", "Términos", "Cookies"].map((item) => (
              <a
                key={item}
                href="#"
                className="text-xs text-[oklch(0.45_0.03_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors"
                style={{ fontFamily: "'Raleway', sans-serif" }}
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
