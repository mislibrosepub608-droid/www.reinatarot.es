import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Crown, User, LogOut, Settings } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { trpc } from "@/lib/trpc";

const navLinks = [
  { href: "/", label: "Inicio" },
  { href: "/tarotistas", label: "Tarotistas" },
  { href: "/consulta", label: "Consulta IA" },
  { href: "/reservas", label: "Reservas" },
  { href: "/bonos", label: "Bonos" },
  { href: "/sobre-nosotras", label: "Sobre Nosotras" },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { logout(); window.location.href = "/"; },
  });

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[oklch(0.08_0.005_285/0.95)] backdrop-blur-md border-b border-[oklch(0.78_0.14_85/0.2)]">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <img
            src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/XSWdfaBQscIVSIoo.png"
            alt="Tarot Reina - Sabiduría Ancestral"
            className="h-12 w-auto object-contain transition-all duration-300 group-hover:scale-105"
            style={{ filter: "drop-shadow(0 0 8px oklch(0.78 0.14 85 / 0.4))" }}
          />
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`px-4 py-2 text-sm font-medium tracking-wider transition-all duration-200 rounded-md ${
                location === link.href
                  ? "text-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.1)]"
                  : "text-[oklch(0.75_0.02_85)] hover:text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.05)]"
              }`}
              style={{ fontFamily: "'Cinzel', serif", fontSize: "0.75rem" }}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Auth Area */}
        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] hover:border-[oklch(0.78_0.14_85)] font-cinzel text-xs tracking-wider"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  <User className="w-4 h-4 mr-2" />
                  {user.name?.split(" ")[0] ?? "Mi Cuenta"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)]"
              >
                <DropdownMenuItem asChild>
                  <Link href="/perfil" className="flex items-center gap-2 cursor-pointer text-[oklch(0.95_0.02_85)] hover:text-[oklch(0.78_0.14_85)]">
                    <User className="w-4 h-4" /> Mi Perfil
                  </Link>
                </DropdownMenuItem>
                {user.role === "admin" && (
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="flex items-center gap-2 cursor-pointer text-[oklch(0.95_0.02_85)] hover:text-[oklch(0.78_0.14_85)]">
                      <Settings className="w-4 h-4" /> Panel Admin
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator className="bg-[oklch(0.78_0.14_85/0.2)]" />
                <DropdownMenuItem
                  onClick={() => logoutMutation.mutate()}
                  className="flex items-center gap-2 cursor-pointer text-[oklch(0.95_0.02_85)] hover:text-red-400"
                >
                  <LogOut className="w-4 h-4" /> Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              asChild
              size="sm"
              className="btn-gold text-xs tracking-widest px-5"
              style={{
                background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                color: "oklch(0.08 0.005 285)",
                fontFamily: "'Cinzel', serif",
                letterSpacing: "0.1em",
              }}
            >
              <a href={getLoginUrl()}>Iniciar Sesión</a>
            </Button>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden p-2 text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] rounded-md transition-colors"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-[oklch(0.09_0.006_285)] border-t border-[oklch(0.78_0.14_85/0.2)] py-4">
          <nav className="container flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className={`px-4 py-3 text-sm font-medium tracking-wider rounded-md transition-colors ${
                  location === link.href
                    ? "text-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.1)]"
                    : "text-[oklch(0.75_0.02_85)] hover:text-[oklch(0.78_0.14_85)]"
                }`}
                style={{ fontFamily: "'Cinzel', serif", fontSize: "0.75rem" }}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-3 border-t border-[oklch(0.78_0.14_85/0.2)] mt-2">
              {isAuthenticated ? (
                <div className="flex flex-col gap-2">
                  <Link href="/perfil" onClick={() => setMobileOpen(false)} className="px-4 py-2 text-sm text-[oklch(0.78_0.14_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                    Mi Perfil
                  </Link>
                  {user?.role === "admin" && (
                    <Link href="/admin" onClick={() => setMobileOpen(false)} className="px-4 py-2 text-sm text-[oklch(0.78_0.14_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                      Panel Admin
                    </Link>
                  )}
                  <button
                    onClick={() => { logoutMutation.mutate(); setMobileOpen(false); }}
                    className="px-4 py-2 text-sm text-left text-red-400"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    Cerrar Sesión
                  </button>
                </div>
              ) : (
                <a
                  href={getLoginUrl()}
                  className="block mx-4 py-2 text-center text-sm rounded-md"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                    color: "oklch(0.08 0.005 285)",
                    fontFamily: "'Cinzel', serif",
                    letterSpacing: "0.1em",
                  }}
                >
                  Iniciar Sesión
                </a>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
