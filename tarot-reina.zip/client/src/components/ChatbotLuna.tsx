import { useState, useRef, useEffect } from "react";
import { X, Moon, Send, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const LUNA_SESSION_KEY = "luna_chat_session";

export default function ChatbotLuna() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hola, soy **Luna**, tu guía espiritual en Tarot Reina ✨\n\nEstoy aquí para ayudarte a descubrir el camino que las cartas tienen para ti. ¿Tienes alguna pregunta sobre nuestras tarotistas, servicios o simplemente quieres explorar el mundo del tarot?",
    },
  ]);
  const [sessionKey] = useState(() => {
    const stored = sessionStorage.getItem(LUNA_SESSION_KEY);
    if (stored) return stored;
    const key = `luna_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    sessionStorage.setItem(LUNA_SESSION_KEY, key);
    return key;
  });
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const sendToLuna = trpc.luna.chat.useMutation({
    onMutate: ({ message: msg }) => {
      setMessages((prev) => [...prev, { role: "user", content: msg }]);
      setMessage("");
      setIsTyping(true);
    },
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: "assistant", content: data.content }]);
      setIsTyping(false);
    },
    onError: () => {
      setMessages((prev) => [...prev, { role: "assistant", content: "Las estrellas me susurran que vuelvas a intentarlo en un momento, querida alma." }]);
      setIsTyping(false);
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!message.trim() || sendToLuna.isPending) return;
    sendToLuna.mutate({ sessionKey, message: message.trim() });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Chat Window */}
      {isOpen && (
        <div
          className="fixed bottom-24 right-6 z-50 w-80 rounded-2xl border border-[oklch(0.78_0.14_85/0.4)] overflow-hidden shadow-2xl"
          style={{
            background: "oklch(0.09 0.006 285)",
            boxShadow: "0 0 40px oklch(0.78 0.14 85 / 0.2), 0 20px 60px rgba(0,0,0,0.5)",
          }}
        >
          {/* Header */}
          <div
            className="p-4 flex items-center justify-between"
            style={{ background: "linear-gradient(135deg, oklch(0.12 0.01 285), oklch(0.15 0.02 290))", borderBottom: "1px solid oklch(0.78 0.14 85 / 0.2)" }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center border border-[oklch(0.78_0.14_85/0.5)]"
                style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))" }}
              >
                <Moon className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
              </div>
              <div>
                <div className="text-sm font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
                  Luna
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-xs text-[oklch(0.55_0.03_85)]">Guía Espiritual</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-[oklch(0.50_0.03_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="h-72 overflow-y-auto p-3 space-y-3">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "assistant" && (
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center mr-2 shrink-0 mt-1 border border-[oklch(0.78_0.14_85/0.3)]"
                    style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))" }}
                  >
                    <Moon className="w-3 h-3" style={{ color: "oklch(0.78 0.14 85)" }} />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-xl px-3 py-2 text-xs leading-relaxed ${
                    msg.role === "user"
                      ? "bg-[oklch(0.78_0.14_85/0.15)] text-[oklch(0.90_0.03_85)] border border-[oklch(0.78_0.14_85/0.25)]"
                      : "bg-[oklch(0.12_0.01_285)] text-[oklch(0.85_0.03_85)] border border-[oklch(0.78_0.14_85/0.1)]"
                  }`}
                  style={{ fontFamily: msg.role === "assistant" ? "'EB Garamond', serif" : "'Raleway', sans-serif", fontSize: "0.8rem" }}
                >
                  {msg.role === "assistant" ? <Streamdown>{msg.content}</Streamdown> : msg.content}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="w-6 h-6 rounded-full flex items-center justify-center mr-2 shrink-0 border border-[oklch(0.78_0.14_85/0.3)]"
                  style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))" }}>
                  <Moon className="w-3 h-3" style={{ color: "oklch(0.78 0.14 85)" }} />
                </div>
                <div className="bg-[oklch(0.12_0.01_285)] border border-[oklch(0.78_0.14_85/0.1)] rounded-xl px-3 py-2">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="w-1.5 h-1.5 rounded-full bg-[oklch(0.78_0.14_85/0.6)] animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-[oklch(0.78_0.14_85/0.15)]">
            <div className="flex gap-2">
              <input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Pregunta a Luna..."
                className="flex-1 px-3 py-2 rounded-lg text-xs bg-[oklch(0.12_0.01_285)] border border-[oklch(0.78_0.14_85/0.25)] text-[oklch(0.90_0.03_85)] placeholder:text-[oklch(0.40_0.02_85)] focus:outline-none focus:border-[oklch(0.78_0.14_85)]"
                style={{ fontFamily: "'Raleway', sans-serif" }}
              />
              <button
                onClick={handleSend}
                disabled={!message.trim() || sendToLuna.isPending}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-all"
                style={{
                  background: message.trim() ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))" : "oklch(0.16 0.015 285)",
                  color: message.trim() ? "oklch(0.08 0.005 285)" : "oklch(0.45 0.03 85)",
                }}
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
        style={{
          background: isOpen
            ? "oklch(0.16 0.015 285)"
            : "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
          boxShadow: "0 0 30px oklch(0.78 0.14 85 / 0.4), 0 8px 20px rgba(0,0,0,0.4)",
          border: "2px solid oklch(0.78 0.14 85 / 0.5)",
        }}
        aria-label="Chatbot Luna"
      >
        {isOpen ? (
          <X className="w-5 h-5" style={{ color: "oklch(0.78 0.14 85)" }} />
        ) : (
          <Moon className="w-6 h-6" style={{ color: "oklch(0.08 0.005 285)" }} fill="oklch(0.08 0.005 285)" />
        )}
        {!isOpen && (
          <span
            className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold"
            style={{ background: "oklch(0.65 0.15 160)", color: "white" }}
          >
            <Sparkles className="w-2.5 h-2.5" />
          </span>
        )}
      </button>
    </>
  );
}
