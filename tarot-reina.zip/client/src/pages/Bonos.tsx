import { Crown, Sparkles, CheckCircle, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";
import { Link } from "wouter";

export default function Bonos() {
  const { isAuthenticated } = useAuth();
  const { data: bonos } = trpc.bonos.list.useQuery();
  const { data: myBonos } = trpc.bonos.myBonos.useQuery(undefined, { enabled: isAuthenticated });
  const utils = trpc.useUtils();

  const purchase = trpc.bonos.purchase.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) {
        toast.success("Redirigiendo al pago seguro con Stripe...");
        window.open(data.checkoutUrl, "_blank");
      }
    },
    onError: () => toast.error("Error al procesar el bono. Inténtalo de nuevo."),
  });

  const features = [
    "Acceso a las 45 tarotistas IA",
    "Historial de consultas guardado",
    "Disponible 24 horas al día",
    "Consultas ilimitadas en el período",
    "Soporte prioritario",
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-5xl">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.78_0.14_85/0.05)] mb-6">
            <Star className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} />
            <span className="text-xs tracking-[0.2em] uppercase" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
              Bonos y Paquetes
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4" style={{
            fontFamily: "'Cinzel', serif",
            background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
          }}>
            Elige tu Camino
          </h1>
          <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.14_85/0.6)] to-transparent max-w-xs mx-auto mb-4" />
          <p className="text-[oklch(0.65_0.03_85)] max-w-xl mx-auto" style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic", fontSize: "1.1rem" }}>
            Invierte en tu bienestar espiritual con nuestros paquetes de consultas. Ahorra más cuanto más consultas.
          </p>
        </div>

        {/* My Active Bonos */}
        {isAuthenticated && myBonos && myBonos.length > 0 && (
          <div className="mb-12">
            <h2 className="text-lg font-bold mb-4" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Mis Bonos Activos
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myBonos.map((b) => (
                <div key={b.id} className="p-5 rounded-xl border border-green-500/30 bg-green-500/5 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold text-[oklch(0.88_0.05_85)] mb-1" style={{ fontFamily: "'Cinzel', serif" }}>
                      {String(b.bonoName)}
                    </div>
                    <div className="text-xs text-[oklch(0.60_0.03_85)]">
                      {b.sessionsUsed ?? 0}/{b.sessionsTotal} consultas usadas
                    </div>
                    <div className="text-xs text-[oklch(0.50_0.03_85)] mt-0.5">
                      Válido hasta: {new Date(b.expiresAt!).toLocaleDateString("es-ES")}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                      {b.sessionsTotal - (b.sessionsUsed ?? 0)}
                    </div>
                    <div className="text-xs text-[oklch(0.55_0.03_85)]">restantes</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bonos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {bonos?.map((bono) => {
            const discount = bono.originalPrice
              ? Math.round((1 - parseFloat(bono.price) / parseFloat(bono.originalPrice)) * 100)
              : 0;

            return (
              <div
                key={bono.id}
                className={`relative p-6 rounded-2xl border transition-all duration-300 flex flex-col ${
                  bono.featured
                    ? "border-[oklch(0.78_0.14_85/0.7)] bg-[oklch(0.12_0.01_285)] shadow-[0_0_40px_oklch(0.78_0.14_85/0.2)]"
                    : "border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)]"
                }`}
              >
                {bono.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span
                      className="px-4 py-1 rounded-full text-xs font-bold tracking-widest"
                      style={{
                        background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                        color: "oklch(0.08 0.005 285)",
                        fontFamily: "'Cinzel', serif",
                      }}
                    >
                      MÁS POPULAR
                    </span>
                  </div>
                )}

                {discount > 0 && (
                  <Badge className="absolute top-4 right-4 bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                    -{discount}%
                  </Badge>
                )}

                <div className="mb-4">
                  <h3 className="text-xl font-bold mb-1" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
                    {bono.name}
                  </h3>
                  {bono.description && (
                    <p className="text-sm text-[oklch(0.60_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                      {bono.description}
                    </p>
                  )}
                </div>

                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-4xl font-bold" style={{
                    fontFamily: "'Cinzel', serif",
                    background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
                  }}>
                    {parseFloat(bono.price).toFixed(0)}€
                  </span>
                  {bono.originalPrice && (
                    <span className="text-sm text-[oklch(0.45_0.03_85)] line-through">
                      {parseFloat(bono.originalPrice).toFixed(0)}€
                    </span>
                  )}
                </div>

                <div className="flex gap-4 mb-6 text-sm">
                  <div className="text-center">
                    <div className="font-bold text-[oklch(0.78_0.14_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                      {bono.sessions}
                    </div>
                    <div className="text-xs text-[oklch(0.50_0.03_85)]">consulta{bono.sessions > 1 ? "s" : ""}</div>
                  </div>
                  <div className="w-px bg-[oklch(0.78_0.14_85/0.2)]" />
                  <div className="text-center">
                    <div className="font-bold text-[oklch(0.78_0.14_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                      {bono.validDays}
                    </div>
                    <div className="text-xs text-[oklch(0.50_0.03_85)]">días válido</div>
                  </div>
                  <div className="w-px bg-[oklch(0.78_0.14_85/0.2)]" />
                  <div className="text-center">
                    <div className="font-bold text-[oklch(0.78_0.14_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                      {(parseFloat(bono.price) / bono.sessions).toFixed(0)}€
                    </div>
                    <div className="text-xs text-[oklch(0.50_0.03_85)]">por consulta</div>
                  </div>
                </div>

                <ul className="space-y-2 mb-6 flex-1">
                  {features.slice(0, 3 + (bono.sessions > 5 ? 2 : bono.sessions > 1 ? 1 : 0)).map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-[oklch(0.70_0.03_85)]">
                      <CheckCircle className="w-4 h-4 shrink-0" style={{ color: "oklch(0.78 0.14 85)" }} />
                      {f}
                    </li>
                  ))}
                </ul>

                {isAuthenticated ? (
                  <Button
                    onClick={() => purchase.mutate({ bonoId: bono.id, origin: window.location.origin })}
                    disabled={purchase.isPending}
                    className="w-full text-xs tracking-widest"
                    style={{
                      background: bono.featured
                        ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))"
                        : "oklch(0.16 0.015 285)",
                      color: bono.featured ? "oklch(0.08 0.005 285)" : "oklch(0.78 0.14 85)",
                      fontFamily: "'Cinzel', serif",
                      letterSpacing: "0.1em",
                      border: bono.featured ? "none" : "1px solid oklch(0.78 0.14 85 / 0.3)",
                    }}
                  >
                    <Sparkles className="w-3.5 h-3.5 mr-2" />
                    {purchase.isPending ? "Procesando..." : "Activar Bono"}
                  </Button>
                ) : (
                  <Button
                    asChild
                    className="w-full text-xs tracking-widest"
                    style={{
                      background: bono.featured
                        ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))"
                        : "oklch(0.16 0.015 285)",
                      color: bono.featured ? "oklch(0.08 0.005 285)" : "oklch(0.78 0.14 85)",
                      fontFamily: "'Cinzel', serif",
                      letterSpacing: "0.1em",
                      border: bono.featured ? "none" : "1px solid oklch(0.78 0.14 85 / 0.3)",
                    }}
                  >
                    <a href={getLoginUrl()}>
                      <Sparkles className="w-3.5 h-3.5 mr-2" />
                      Iniciar Sesión para Comprar
                    </a>
                  </Button>
                )}
              </div>
            );
          })}
        </div>

        {/* FAQ */}
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
            Preguntas Frecuentes
          </h2>
          <div className="space-y-4">
            {[
              { q: "¿Cuándo caducan los bonos?", a: "Cada bono tiene su período de validez indicado. Una vez activado, el contador comienza a correr." },
              { q: "¿Puedo usar el bono con cualquier tarotista?", a: "Sí, los bonos son válidos para cualquiera de nuestras 45 tarotistas IA disponibles en la plataforma." },
              { q: "¿Qué pasa si no uso todas las consultas?", a: "Las consultas no utilizadas se pierden al expirar el bono. Te recomendamos elegir el paquete que mejor se adapte a tu ritmo." },
              { q: "¿Hay garantía de devolución?", a: "Ofrecemos garantía de satisfacción en la primera consulta. Si no estás satisfecha, contacta con nosotras en reinatarot78@gmail.com." },
            ].map((faq) => (
              <div key={faq.q} className="p-5 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)]">
                <h3 className="text-sm font-bold mb-2 text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                  {faq.q}
                </h3>
                <p className="text-sm text-[oklch(0.60_0.03_85)]" style={{ fontFamily: "'Raleway', sans-serif" }}>
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
