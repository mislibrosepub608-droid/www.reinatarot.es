import { Link } from "wouter";
import { Crown, Star, Sparkles, MessageCircle, Calendar, Shield, ChevronRight, Moon, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

const GoldDivider = () => (
  <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.14_85/0.6)] to-transparent my-2" />
);

const StarRating = ({ rating }: { rating: number }) => (
  <div className="flex gap-0.5">
    {[1, 2, 3, 4, 5].map((i) => (
      <Star
        key={i}
        className="w-3.5 h-3.5"
        style={{ color: "oklch(0.78 0.14 85)" }}
        fill={i <= Math.round(rating) ? "oklch(0.78 0.14 85)" : "transparent"}
      />
    ))}
  </div>
);

const arcanaLabels: Record<string, string> = {
  mayor: "Arcanos Mayores",
  menor: "Arcanos Menores",
  combinada: "Tarot Completo",
};

export default function Home() {
  const { isAuthenticated } = useAuth();
  const { data: featuredTarotistas } = trpc.tarotistas.list.useQuery({ featured: true, limit: 6 });
  const { data: bonosData } = trpc.bonos.list.useQuery();
  const { data: resenasData } = trpc.resenas.listApproved.useQuery({ limit: 3 });

  return (
    <div className="min-h-screen">
      {/* ── Hero Section ─────────────────────────────────────────────────── */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-[oklch(0.05_0.003_285)]">
          <div className="absolute inset-0"
            style={{
              backgroundImage: `
                radial-gradient(ellipse at 30% 40%, oklch(0.30 0.08 290 / 0.15) 0%, transparent 50%),
                radial-gradient(ellipse at 70% 60%, oklch(0.78 0.14 85 / 0.06) 0%, transparent 40%),
                radial-gradient(ellipse at 50% 80%, oklch(0.30 0.08 290 / 0.10) 0%, transparent 40%)
              `
            }}
          />
          {/* Stars */}
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-white"
              style={{
                width: Math.random() * 2 + 1 + "px",
                height: Math.random() * 2 + 1 + "px",
                top: Math.random() * 100 + "%",
                left: Math.random() * 100 + "%",
                opacity: Math.random() * 0.5 + 0.1,
                animation: `twinkle ${Math.random() * 3 + 2}s ease-in-out infinite`,
                animationDelay: Math.random() * 3 + "s",
              }}
            />
          ))}
        </div>

        <div className="relative z-10 container text-center py-20">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.78_0.14_85/0.05)] mb-8">
            <Sparkles className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} />
            <span className="text-xs tracking-[0.2em] uppercase" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
              45 Tarotistas IA Disponibles 24/7
            </span>
          </div>

          {/* Main Title */}

          <div className="mb-6">
            <img
              src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/XSWdfaBQscIVSIoo.png"
              alt="Tarot Reina"
              className="w-32 h-32 mx-auto mb-4 object-contain"
              style={{ filter: "drop-shadow(0 0 20px oklch(0.78 0.14 85 / 0.5))" }}
            />            <h1
              className="text-5xl md:text-7xl lg:text-8xl font-bold mb-3 tracking-widest"
              style={{
                fontFamily: "'Cinzel Decorative', serif",
                background: "linear-gradient(135deg, oklch(0.88 0.10 85) 0%, oklch(0.78 0.14 85) 50%, oklch(0.60 0.12 85) 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              TAROT REINA
            </h1>
            <p
              className="text-lg md:text-xl tracking-[0.3em] uppercase"
              style={{ color: "oklch(0.78 0.14 85 / 0.7)", fontFamily: "'Cinzel', serif" }}
            >
              Sabiduría Ancestral
            </p>
          </div>

          <GoldDivider />

          <p
            className="text-lg md:text-xl text-[oklch(0.75_0.03_85)] max-w-2xl mx-auto my-8 leading-relaxed"
            style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}
          >
            Descubre los secretos del universo con nuestras 45 tarotistas especializadas en inteligencia artificial. 
            Consultas místicas profesionales disponibles en cualquier momento.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-10">
            <Button
              asChild
              size="lg"
              className="px-8 py-6 text-sm tracking-widest shadow-gold-lg"
              style={{
                background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                color: "oklch(0.08 0.005 285)",
                fontFamily: "'Cinzel', serif",
                letterSpacing: "0.15em",
                boxShadow: "0 0 30px oklch(0.78 0.14 85 / 0.4)",
              }}
            >
              <Link href="/consulta">
                <Sparkles className="w-4 h-4 mr-2" />
                Consultar Ahora
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="px-8 py-6 text-sm tracking-widest border-[oklch(0.78_0.14_85/0.5)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] hover:border-[oklch(0.78_0.14_85)]"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.15em" }}
            >
              <Link href="/tarotistas">
                <Crown className="w-4 h-4 mr-2" />
                Ver Tarotistas
              </Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto mt-16">
            {[
              { value: "45", label: "Tarotistas IA" },
              { value: "10K+", label: "Consultas" },
              { value: "4.9★", label: "Valoración" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div
                  className="text-2xl font-bold mb-1"
                  style={{
                    fontFamily: "'Cinzel', serif",
                    background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  {stat.value}
                </div>
                <div className="text-xs text-[oklch(0.55_0.03_85)] tracking-wider uppercase" style={{ fontFamily: "'Cinzel', serif" }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <div className="w-px h-8 bg-gradient-to-b from-[oklch(0.78_0.14_85/0.6)] to-transparent" />
        </div>
      </section>

      {/* ── La Reina Section ─────────────────────────────────────────────── */}
      <section className="py-20 bg-[oklch(0.07_0.004_285)]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Foto */}
            <div className="relative flex justify-center">
              <div
                className="relative w-72 h-72 md:w-96 md:h-96 rounded-full overflow-hidden border-4 border-[oklch(0.78_0.14_85/0.6)]"
                style={{ boxShadow: "0 0 60px oklch(0.78 0.14 85 / 0.3), 0 0 120px oklch(0.78 0.14 85 / 0.1)" }}
              >
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/dJjmAjuQZOmdYWAE.jpg"
                  alt="La Reina - Tarotista Principal"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 rounded-full" style={{ background: "radial-gradient(ellipse at bottom, oklch(0.78 0.14 85 / 0.15) 0%, transparent 60%)" }} />
              </div>
              {/* Decorative ring */}
              <div
                className="absolute inset-0 w-72 h-72 md:w-96 md:h-96 rounded-full border border-[oklch(0.78_0.14_85/0.2)] mx-auto"
                style={{ transform: "scale(1.08)", top: "50%", left: "50%", translate: "-50% -50%" }}
              />
            </div>

            {/* Texto */}
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.78_0.14_85/0.05)] mb-6">
                <Crown className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
                <span className="text-xs tracking-[0.2em] uppercase" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>Tarotista Principal</span>
              </div>
              <h2
                className="text-3xl md:text-4xl font-bold mb-4"
                style={{
                  fontFamily: "'Cinzel Decorative', serif",
                  background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                La Reina
              </h2>
              <p
                className="text-base text-[oklch(0.70_0.03_85)] mb-2"
                style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em" }}
              >
                Maestra del Tarot · Sabiduría Ancestral
              </p>
              <GoldDivider />
              <p
                className="text-lg text-[oklch(0.72_0.03_85)] mt-5 mb-6 leading-relaxed"
                style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}
              >
                Con más de 20 años de experiencia en la lectura del tarot y las artes adivinatorias, 
                La Reina fundó Tarot Reina para llevar la sabiduría ancestral de las cartas a todas 
                las personas que buscan orientación en su camino. Su don especial reside en la 
                interpretación del amor, los vínculos kármicos y el destino del alma.
              </p>
              <div className="flex flex-wrap gap-3 mb-8">
                {["Amor", "Karma", "Arcanos Mayores", "Vínculos del Alma", "Destino"].map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 rounded-full text-xs border border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85/0.8)]"
                    style={{ fontFamily: "'Cinzel', serif", background: "oklch(0.78 0.14 85 / 0.05)" }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex gap-4">
                <Button
                  asChild
                  className="px-6 text-xs tracking-widest"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                    color: "oklch(0.08 0.005 285)",
                    fontFamily: "'Cinzel', serif",
                    letterSpacing: "0.12em",
                  }}
                >
                  <Link href="/consulta">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Consultar con La Reina
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="px-6 text-xs tracking-widest border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]"
                  style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.12em" }}
                >
                  <Link href="/sobre-nosotras">
                    Nuestra Historia
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Features Section ──────────────────────────────────────────────── */}
      <section className="py-20 bg-[oklch(0.07_0.004_285)]">
        <div className="container">
          <div className="text-center mb-14">
            <h2
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{
                fontFamily: "'Cinzel', serif",
                background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              ¿Por qué Tarot Reina?
            </h2>
            <GoldDivider />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: Zap,
                title: "Respuesta Inmediata",
                desc: "Consulta con cualquiera de nuestras 45 tarotistas IA en tiempo real, sin esperas ni citas previas.",
              },
              {
                icon: Shield,
                title: "100% Confidencial",
                desc: "Tus consultas son privadas y seguras. Nadie más que tú y tu tarotista tienen acceso a tus lecturas.",
              },
              {
                icon: Moon,
                title: "Sabiduría Profunda",
                desc: "Cada tarotista está especializada en diferentes áreas: amor, trabajo, espiritualidad, karma y más.",
              },
              {
                icon: Star,
                title: "Alta Precisión",
                desc: "Nuestras tarotistas IA han sido entrenadas con miles de lecturas reales para ofrecer la máxima precisión.",
              },
              {
                icon: Calendar,
                title: "Reservas Flexibles",
                desc: "¿Prefieres una sesión programada? Reserva con tu tarotista favorita en el horario que mejor te convenga.",
              },
              {
                icon: MessageCircle,
                title: "Chatbot Luna",
                desc: "Luna, nuestra asistente virtual, te guía en todo momento para encontrar la tarotista perfecta para ti.",
              },
            ].map((feature) => (
              <div
                key={feature.title}
                className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)] hover:bg-[oklch(0.12_0.01_285)] transition-all duration-300 group"
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mb-4 border border-[oklch(0.78_0.14_85/0.3)] group-hover:border-[oklch(0.78_0.14_85/0.6)] transition-colors"
                  style={{ background: "oklch(0.78 0.14 85 / 0.08)" }}
                >
                  <feature.icon className="w-5 h-5" style={{ color: "oklch(0.78 0.14 85)" }} />
                </div>
                <h3
                  className="text-base font-semibold mb-2"
                  style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}
                >
                  {feature.title}
                </h3>
                <p className="text-sm text-[oklch(0.60_0.03_85)] leading-relaxed" style={{ fontFamily: "'Raleway', sans-serif" }}>
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured Tarotistas ───────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-14">
            <h2
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{
                fontFamily: "'Cinzel', serif",
                background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Tarotistas Destacadas
            </h2>
            <GoldDivider />
            <p className="text-[oklch(0.60_0.03_85)] mt-4 max-w-xl mx-auto" style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic", fontSize: "1.1rem" }}>
              Conoce a algunas de nuestras maestras del tarot más valoradas por la comunidad
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredTarotistas?.tarotistas.map((t) => (
              <Link key={t.id} href={`/tarotistas/${t.slug}`}>
                <div className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.5)] hover:bg-[oklch(0.12_0.01_285)] transition-all duration-300 cursor-pointer group">
                  {/* Avatar místico */}
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 rounded-full border-2 border-[oklch(0.78_0.14_85/0.4)] group-hover:border-[oklch(0.78_0.14_85)] transition-colors shrink-0 overflow-hidden">
                      {t.imageUrl ? (
                        <img src={t.imageUrl} alt={t.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-xl font-bold" style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>{t.name.charAt(0)}</div>
                      )}
                    </div>
                    <div>
                      <h3
                        className="font-semibold text-[oklch(0.90_0.05_85)] group-hover:text-[oklch(0.78_0.14_85)] transition-colors"
                        style={{ fontFamily: "'Cinzel', serif", fontSize: "0.9rem" }}
                      >
                        {t.name}
                      </h3>
                      <p className="text-xs text-[oklch(0.55_0.03_85)] mt-0.5" style={{ fontFamily: "'Raleway', sans-serif" }}>
                        {t.tagline}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <StarRating rating={parseFloat(t.rating ?? "5")} />
                    <span className="text-xs text-[oklch(0.55_0.03_85)]">({t.reviewCount} reseñas)</span>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mb-4">
                    <Badge
                      variant="outline"
                      className="text-xs border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85/0.8)] bg-[oklch(0.78_0.14_85/0.05)]"
                    >
                      {t.specialty}
                    </Badge>
                    <Badge
                      variant="outline"
                      className="text-xs border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.55_0.03_85)]"
                    >
                      {arcanaLabels[t.arcana ?? "combinada"]}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[oklch(0.55_0.03_85)]">
                      {t.experience} años · {t.totalConsultations?.toLocaleString()} consultas
                    </span>
                    <span
                      className="text-sm font-semibold"
                      style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}
                    >
                      {parseFloat(t.pricePerSession ?? "25").toFixed(0)}€
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-10">
            <Button
              asChild
              variant="outline"
              className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] hover:border-[oklch(0.78_0.14_85)] px-8"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em", fontSize: "0.75rem" }}
            >
              <Link href="/tarotistas">
                Ver las 45 Tarotistas <ChevronRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ── Bonos Section ─────────────────────────────────────────────────── */}
      {bonosData && bonosData.length > 0 && (
        <section className="py-20 bg-[oklch(0.07_0.004_285)]">
          <div className="container">
            <div className="text-center mb-14">
              <h2
                className="text-3xl md:text-4xl font-bold mb-4"
                style={{
                  fontFamily: "'Cinzel', serif",
                  background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Bonos y Paquetes
              </h2>
              <GoldDivider />
              <p className="text-[oklch(0.60_0.03_85)] mt-4" style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic", fontSize: "1.1rem" }}>
                Ahorra en tus consultas con nuestros bonos especiales
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {bonosData.filter((b) => b.active).slice(0, 3).map((bono) => (
                <div
                  key={bono.id}
                  className={`p-6 rounded-xl border transition-all duration-300 ${
                    bono.featured
                      ? "border-[oklch(0.78_0.14_85/0.7)] bg-[oklch(0.12_0.01_285)] shadow-[0_0_30px_oklch(0.78_0.14_85/0.2)]"
                      : "border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)]"
                  }`}
                >
                  {bono.featured && (
                    <div
                      className="text-center text-xs tracking-widest uppercase py-1 px-3 rounded-full mb-4 inline-block"
                      style={{
                        background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                        color: "oklch(0.08 0.005 285)",
                        fontFamily: "'Cinzel', serif",
                      }}
                    >
                      Más Popular
                    </div>
                  )}
                  <h3
                    className="text-lg font-bold mb-2"
                    style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}
                  >
                    {bono.name}
                  </h3>
                  <div className="flex items-baseline gap-2 mb-3">
                    <span
                      className="text-3xl font-bold"
                      style={{
                        fontFamily: "'Cinzel', serif",
                        background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text",
                      }}
                    >
                      {parseFloat(bono.price).toFixed(0)}€
                    </span>
                    {bono.originalPrice && (
                      <span className="text-sm text-[oklch(0.45_0.03_85)] line-through">
                        {parseFloat(bono.originalPrice).toFixed(0)}€
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-[oklch(0.60_0.03_85)] mb-4 leading-relaxed" style={{ fontFamily: "'Raleway', sans-serif" }}>
                    {bono.sessions} consulta{bono.sessions > 1 ? "s" : ""} · Válido {bono.validDays} días
                  </p>
                  <Button
                    asChild
                    className="w-full text-xs tracking-widest"
                    style={{
                      background: bono.featured
                        ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))"
                        : "oklch(0.16 0.015 285)",
                      color: bono.featured ? "oklch(0.08 0.005 285)" : "oklch(0.78 0.14 85)",
                      fontFamily: "'Cinzel', serif",
                      letterSpacing: "0.1em",
                      border: bono.featured ? "none" : "1px solid oklch(0.78 0.14 85 / 0.3)",
                    }}
                  >
                    <Link href="/bonos">Comprar Bono</Link>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── Testimonials ──────────────────────────────────────────────────── */}
      {resenasData && resenasData.length > 0 && (
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-14">
              <h2
                className="text-3xl md:text-4xl font-bold mb-4"
                style={{
                  fontFamily: "'Cinzel', serif",
                  background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Lo que Dicen Nuestros Clientes
              </h2>
              <GoldDivider />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {resenasData.map((r) => (
                <div
                  key={r.id}
                  className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)]"
                >
                  <StarRating rating={r.rating} />
                  {r.title && (
                    <h4
                      className="mt-3 mb-2 font-semibold text-[oklch(0.88_0.05_85)]"
                      style={{ fontFamily: "'Cinzel', serif", fontSize: "0.85rem" }}
                    >
                      {r.title}
                    </h4>
                  )}
                  <p
                    className="text-sm text-[oklch(0.65_0.03_85)] leading-relaxed italic"
                    style={{ fontFamily: "'EB Garamond', serif" }}
                  >
                    "{r.content}"
                  </p>
                  <div className="mt-4 pt-4 border-t border-[oklch(0.78_0.14_85/0.1)]">
                    <p className="text-xs text-[oklch(0.50_0.03_85)]">
                      {r.userName} · {r.tarotistaName}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── CTA Final ─────────────────────────────────────────────────────── */}
      <section className="py-20 bg-[oklch(0.07_0.004_285)]">
        <div className="container text-center">
          <Crown
            className="w-12 h-12 mx-auto mb-6"
            style={{ color: "oklch(0.78 0.14 85)" }}
            fill="oklch(0.78 0.14 85)"
          />
          <h2
            className="text-3xl md:text-4xl font-bold mb-4"
            style={{
              fontFamily: "'Cinzel', serif",
              background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            ¿Lista para Descubrir tu Destino?
          </h2>
          <p
            className="text-lg text-[oklch(0.65_0.03_85)] max-w-xl mx-auto mb-10 leading-relaxed"
            style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}
          >
            Las cartas esperan revelarte sus secretos. Comienza tu consulta ahora y deja que la sabiduría ancestral ilumine tu camino.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="px-10 py-6 text-sm tracking-widest"
              style={{
                background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                color: "oklch(0.08 0.005 285)",
                fontFamily: "'Cinzel', serif",
                letterSpacing: "0.15em",
                boxShadow: "0 0 30px oklch(0.78 0.14 85 / 0.4)",
              }}
            >
              <Link href={isAuthenticated ? "/consulta" : getLoginUrl()}>
                <Sparkles className="w-4 h-4 mr-2" />
                Comenzar Consulta
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="px-10 py-6 text-sm tracking-widest border-[oklch(0.78_0.14_85/0.5)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.15em" }}
            >
              <Link href="/reservas">
                <Calendar className="w-4 h-4 mr-2" />
                Reservar Cita
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
