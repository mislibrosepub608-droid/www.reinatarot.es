import { useState } from "react";
import { Link } from "wouter";
import { Search, Star, Crown, Filter, Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";

const specialties = ["Todas", "Amor", "Trabajo", "Espiritualidad", "Karma", "Futuro", "Salud", "Familia", "Dinero"];
const arcanaOptions = [
  { value: "", label: "Todos los Arcanos" },
  { value: "mayor", label: "Arcanos Mayores" },
  { value: "menor", label: "Arcanos Menores" },
  { value: "combinada", label: "Tarot Completo" },
];

const StarRating = ({ rating }: { rating: number }) => (
  <div className="flex gap-0.5">
    {[1, 2, 3, 4, 5].map((i) => (
      <Star key={i} className="w-3 h-3" style={{ color: "oklch(0.78 0.14 85)" }} fill={i <= Math.round(rating) ? "oklch(0.78 0.14 85)" : "transparent"} />
    ))}
  </div>
);

export default function Tarotistas() {
  const [search, setSearch] = useState("");
  const [selectedSpecialty, setSelectedSpecialty] = useState("Todas");
  const [selectedArcana, setSelectedArcana] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const handleSearch = (val: string) => {
    setSearch(val);
    clearTimeout((window as any)._searchTimer);
    (window as any)._searchTimer = setTimeout(() => setDebouncedSearch(val), 400);
  };

  const { data, isLoading } = trpc.tarotistas.list.useQuery({
    search: debouncedSearch || undefined,
    specialty: selectedSpecialty !== "Todas" ? selectedSpecialty : undefined,
    arcana: selectedArcana ? (selectedArcana as "mayor" | "menor" | "combinada") : undefined,
    limit: 50,
  });

  return (
    <div className="min-h-screen py-12">
      {/* Header */}
      <div className="container mb-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.78_0.14_85/0.05)] mb-6">
            <Crown className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} />
            <span className="text-xs tracking-[0.2em] uppercase" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
              45 Maestras del Tarot
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4" style={{
            fontFamily: "'Cinzel', serif",
            background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
          }}>
            Nuestras Tarotistas
          </h1>
          <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.14_85/0.6)] to-transparent max-w-xs mx-auto mb-4" />
          <p className="text-[oklch(0.65_0.03_85)] max-w-xl mx-auto" style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic", fontSize: "1.1rem" }}>
            Cada tarotista posee una especialidad única. Encuentra la que mejor resuene con tu consulta.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 max-w-3xl mx-auto">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[oklch(0.55_0.03_85)]" />
            <Input
              placeholder="Buscar tarotista..."
              value={search}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10 bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] placeholder:text-[oklch(0.45_0.03_85)] focus:border-[oklch(0.78_0.14_85)]"
            />
          </div>
          <select
            value={selectedArcana}
            onChange={(e) => setSelectedArcana(e.target.value)}
            className="px-4 py-2 rounded-md bg-[oklch(0.11_0.008_285)] border border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] text-sm focus:outline-none focus:border-[oklch(0.78_0.14_85)]"
            style={{ fontFamily: "'Raleway', sans-serif" }}
          >
            {arcanaOptions.map((o) => (
              <option key={o.value} value={o.value} style={{ background: "oklch(0.11 0.008 285)" }}>{o.label}</option>
            ))}
          </select>
        </div>

        {/* Specialty pills */}
        <div className="flex flex-wrap gap-2 justify-center mt-5">
          {specialties.map((s) => (
            <button
              key={s}
              onClick={() => setSelectedSpecialty(s)}
              className={`px-4 py-1.5 rounded-full text-xs tracking-wider transition-all duration-200 border ${
                selectedSpecialty === s
                  ? "border-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.15)] text-[oklch(0.88_0.08_85)]"
                  : "border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.60_0.03_85)] hover:border-[oklch(0.78_0.14_85/0.5)] hover:text-[oklch(0.78_0.14_85)]"
              }`}
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="container">
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="h-52 rounded-xl bg-[oklch(0.11_0.008_285)] animate-pulse border border-[oklch(0.78_0.14_85/0.1)]" />
            ))}
          </div>
        ) : (
          <>
            <p className="text-sm text-[oklch(0.55_0.03_85)] mb-5" style={{ fontFamily: "'Raleway', sans-serif" }}>
              {data?.total ?? 0} tarotistas encontradas
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {data?.tarotistas.map((t) => (
                <Link key={t.id} href={`/tarotistas/${t.slug}`}>
                  <div className="p-5 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.5)] hover:bg-[oklch(0.12_0.01_285)] transition-all duration-300 cursor-pointer group h-full flex flex-col">
                    {/* Avatar */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-14 h-14 rounded-full border-2 border-[oklch(0.78_0.14_85/0.3)] group-hover:border-[oklch(0.78_0.14_85)] transition-colors shrink-0 overflow-hidden">
                        {t.imageUrl ? (
                          <img src={t.imageUrl} alt={t.name} className="w-full h-full object-cover" />
                        ) : (
                          <div
                            className="w-full h-full flex items-center justify-center text-lg font-bold"
                            style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}
                          >
                            {t.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold text-sm text-[oklch(0.90_0.05_85)] group-hover:text-[oklch(0.78_0.14_85)] transition-colors truncate" style={{ fontFamily: "'Cinzel', serif" }}>
                          {t.name}
                        </h3>
                        <p className="text-xs text-[oklch(0.55_0.03_85)] truncate" style={{ fontFamily: "'Raleway', sans-serif" }}>
                          {t.tagline}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3">
                      <StarRating rating={parseFloat(t.rating ?? "5")} />
                      <span className="text-xs text-[oklch(0.50_0.03_85)]">({t.reviewCount})</span>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-3 flex-1">
                      <Badge variant="outline" className="text-xs border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85/0.8)] bg-[oklch(0.78_0.14_85/0.05)]">
                        {t.specialty}
                      </Badge>
                      {t.available && (
                        <Badge variant="outline" className="text-xs border-green-500/30 text-green-400 bg-green-500/5">
                          Disponible
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-[oklch(0.78_0.14_85/0.1)]">
                      <span className="text-xs text-[oklch(0.50_0.03_85)]">{t.experience} años</span>
                      <span className="text-sm font-bold" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                        {parseFloat(t.pricePerSession ?? "25").toFixed(0)}€
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            {data?.tarotistas.length === 0 && (
              <div className="text-center py-20">
                <Sparkles className="w-12 h-12 mx-auto mb-4 text-[oklch(0.78_0.14_85/0.3)]" />
                <p className="text-[oklch(0.55_0.03_85)]" style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}>
                  No se encontraron tarotistas con esos criterios. Prueba con otros filtros.
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
