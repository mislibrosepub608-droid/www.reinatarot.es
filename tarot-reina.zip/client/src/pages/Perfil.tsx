import { Crown, MessageCircle, Calendar, Star, User, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { toast } from "sonner";

export default function Perfil() {
  const { user, isAuthenticated, logout } = useAuth();
  const { data: sessions } = trpc.chat.getSessions.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myReservas } = trpc.reservas.myReservas.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myBonos } = trpc.bonos.myBonos.useQuery(undefined, { enabled: isAuthenticated });
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { logout(); window.location.href = "/"; },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md p-8 rounded-2xl border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.10_0.007_285)]">
          <Crown className="w-16 h-16 mx-auto mb-6" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
          <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
            Accede a tu Perfil
          </h2>
          <p className="text-[oklch(0.60_0.03_85)] mb-6 italic" style={{ fontFamily: "'EB Garamond', serif" }}>
            Inicia sesión para ver tu historial de consultas, reservas y bonos activos.
          </p>
          <Button asChild style={{
            background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
            color: "oklch(0.08 0.005 285)",
            fontFamily: "'Cinzel', serif",
            letterSpacing: "0.1em",
          }}>
            <a href={getLoginUrl()}>Iniciar Sesión</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Profile Header */}
        <div className="p-8 rounded-2xl border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.10_0.007_285)] mb-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold border-2 border-[oklch(0.78_0.14_85/0.5)]"
                style={{
                  background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.22 0.04 285))",
                  fontFamily: "'Cinzel', serif",
                  color: "oklch(0.78 0.14 85)",
                }}
              >
                {user?.name?.charAt(0) ?? <User className="w-8 h-8" />}
              </div>
              <div>
                <h1 className="text-2xl font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
                  {user?.name ?? "Usuaria"}
                </h1>
                <p className="text-sm text-[oklch(0.60_0.03_85)]">{user?.email}</p>
                {user?.role === "admin" && (
                  <Badge variant="outline" className="mt-1 border-[oklch(0.78_0.14_85/0.5)] text-[oklch(0.78_0.14_85)] text-xs">
                    Administradora
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex gap-3">
              {user?.role === "admin" && (
                <Button asChild variant="outline" size="sm" className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] text-xs" style={{ fontFamily: "'Cinzel', serif" }}>
                  <Link href="/admin">Panel Admin</Link>
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => logoutMutation.mutate()}
                className="text-[oklch(0.60_0.03_85)] hover:text-red-400 text-xs"
              >
                <LogOut className="w-4 h-4 mr-1.5" /> Cerrar Sesión
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-[oklch(0.78_0.14_85/0.1)]">
            {[
              { icon: MessageCircle, label: "Consultas", value: sessions?.length ?? 0 },
              { icon: Calendar, label: "Reservas", value: myReservas?.length ?? 0 },
              { icon: Star, label: "Bonos Activos", value: myBonos?.length ?? 0 },
            ].map((s) => (
              <div key={s.label} className="text-center p-3 rounded-lg bg-[oklch(0.13_0.01_285)]">
                <s.icon className="w-5 h-5 mx-auto mb-1" style={{ color: "oklch(0.78 0.14 85)" }} />
                <div className="text-xl font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                  {s.value}
                </div>
                <div className="text-xs text-[oklch(0.50_0.03_85)]">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Bonos */}
        {myBonos && myBonos.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-bold mb-4" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Bonos Activos
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myBonos.map((b) => (
                <div key={b.id} className="p-4 rounded-xl border border-green-500/30 bg-green-500/5">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-bold text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                        {String(b.bonoName)}
                      </div>
                      <div className="text-xs text-[oklch(0.55_0.03_85)] mt-0.5">
                        Expira: {new Date(b.expiresAt!).toLocaleDateString("es-ES")}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                        {b.sessionsTotal - (b.sessionsUsed ?? 0)}
                      </div>
                      <div className="text-xs text-[oklch(0.50_0.03_85)]">consultas restantes</div>
                    </div>
                  </div>
                  {/* Progress bar */}
                  <div className="mt-3 h-1.5 bg-[oklch(0.14_0.01_285)] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${((b.sessionsUsed ?? 0) / b.sessionsTotal) * 100}%`,
                        background: "linear-gradient(90deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent Sessions */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Consultas Recientes
            </h2>
            <Button asChild variant="outline" size="sm" className="border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] text-xs" style={{ fontFamily: "'Cinzel', serif" }}>
              <Link href="/consulta">Nueva Consulta</Link>
            </Button>
          </div>
          {sessions && sessions.length > 0 ? (
            <div className="space-y-3">
              {sessions.slice(0, 5).map((s) => (
                <div key={s.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <MessageCircle className="w-4 h-4 shrink-0" style={{ color: "oklch(0.78 0.14 85)" }} />
                    <div>
                      <div className="text-sm text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif", fontSize: "0.8rem" }}>
                        {String(s.title)}
                      </div>
                      <div className="text-xs text-[oklch(0.50_0.03_85)] mt-0.5">
                        {new Date(s.updatedAt).toLocaleDateString("es-ES")}
                      </div>
                    </div>
                  </div>
                  <Button asChild variant="ghost" size="sm" className="text-[oklch(0.60_0.03_85)] hover:text-[oklch(0.78_0.14_85)] text-xs">
                    <Link href="/consulta">Continuar</Link>
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 rounded-xl border border-[oklch(0.78_0.14_85/0.1)] bg-[oklch(0.10_0.007_285)]">
              <MessageCircle className="w-8 h-8 mx-auto mb-3 text-[oklch(0.78_0.14_85/0.3)]" />
              <p className="text-sm text-[oklch(0.50_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                Aún no has realizado ninguna consulta. ¡Las cartas te esperan!
              </p>
              <Button asChild className="mt-4 text-xs" style={{
                background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                color: "oklch(0.08 0.005 285)",
                fontFamily: "'Cinzel', serif",
              }}>
                <Link href="/consulta">Comenzar Consulta</Link>
              </Button>
            </div>
          )}
        </div>

        {/* Reservations */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Mis Reservas
            </h2>
            <Button asChild variant="outline" size="sm" className="border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] text-xs" style={{ fontFamily: "'Cinzel', serif" }}>
              <Link href="/reservas">Nueva Reserva</Link>
            </Button>
          </div>
          {myReservas && myReservas.length > 0 ? (
            <div className="space-y-3">
              {myReservas.map((r) => (
                <div key={r.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 shrink-0" style={{ color: "oklch(0.78 0.14 85)" }} />
                    <div>
                      <div className="text-sm text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif", fontSize: "0.8rem" }}>
                        {new Date(r.scheduledAt).toLocaleString("es-ES", { dateStyle: "medium", timeStyle: "short" })}
                      </div>
                      <div className="text-xs text-[oklch(0.50_0.03_85)] mt-0.5">{r.consultationType} · {r.duration} min</div>
                    </div>
                  </div>
                  <Badge variant="outline" className={`text-xs ${
                    r.status === "confirmed" ? "border-green-500/40 text-green-400" :
                    r.status === "completed" ? "border-blue-500/40 text-blue-400" :
                    r.status === "cancelled" ? "border-red-500/40 text-red-400" :
                    "border-yellow-500/40 text-yellow-400"
                  }`}>
                    {r.status === "pending" ? "Pendiente" : r.status === "confirmed" ? "Confirmada" : r.status === "completed" ? "Completada" : "Cancelada"}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 rounded-xl border border-[oklch(0.78_0.14_85/0.1)] bg-[oklch(0.10_0.007_285)]">
              <Calendar className="w-8 h-8 mx-auto mb-3 text-[oklch(0.78_0.14_85/0.3)]" />
              <p className="text-sm text-[oklch(0.50_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                No tienes reservas pendientes.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
