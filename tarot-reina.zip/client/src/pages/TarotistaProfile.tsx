import { useState } from "react";
import { Link, useParams } from "wouter";
import { Star, Crown, Calendar, MessageCircle, ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";

const StarRating = ({ rating, interactive = false, onRate }: { rating: number; interactive?: boolean; onRate?: (r: number) => void }) => (
  <div className="flex gap-1">
    {[1, 2, 3, 4, 5].map((i) => (
      <Star
        key={i}
        className={`${interactive ? "cursor-pointer hover:scale-110 transition-transform" : ""} w-5 h-5`}
        style={{ color: "oklch(0.78 0.14 85)" }}
        fill={i <= Math.round(rating) ? "oklch(0.78 0.14 85)" : "transparent"}
        onClick={() => interactive && onRate?.(i)}
      />
    ))}
  </div>
);

export default function TarotistaProfile() {
  const params = useParams<{ slug: string }>();
  const { isAuthenticated } = useAuth();
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState("");
  const [reviewContent, setReviewContent] = useState("");
  const [showReviewForm, setShowReviewForm] = useState(false);

  const { data: tarotista, isLoading } = trpc.tarotistas.bySlug.useQuery({ slug: params.slug });
  const { data: resenas } = trpc.resenas.byTarotista.useQuery(
    { tarotistaId: tarotista?.id ?? 0 },
    { enabled: !!tarotista?.id }
  );
  const createResena = trpc.resenas.create.useMutation({
    onSuccess: () => {
      toast.success("Reseña enviada para revisión");
      setShowReviewForm(false);
      setReviewContent("");
      setReviewTitle("");
    },
    onError: () => toast.error("Error al enviar la reseña"),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Crown className="w-12 h-12 mx-auto mb-4 animate-pulse" style={{ color: "oklch(0.78 0.14 85)" }} />
          <p className="text-[oklch(0.60_0.03_85)]" style={{ fontFamily: "'Cinzel', serif" }}>Invocando perfil...</p>
        </div>
      </div>
    );
  }

  if (!tarotista) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-[oklch(0.60_0.03_85)] mb-4">Tarotista no encontrada</p>
          <Button asChild variant="outline" className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)]">
            <Link href="/tarotistas"><ArrowLeft className="w-4 h-4 mr-2" /> Volver</Link>
          </Button>
        </div>
      </div>
    );
  }

  const arcanaLabel = { mayor: "Arcanos Mayores", menor: "Arcanos Menores", combinada: "Tarot Completo" }[tarotista.arcana ?? "combinada"];

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Back */}
        <Link href="/tarotistas" className="inline-flex items-center gap-2 text-sm text-[oklch(0.60_0.03_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Volver a Tarotistas
        </Link>

        {/* Profile Card */}
        <div className="p-8 rounded-2xl border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.10_0.007_285)] mb-8">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            {/* Avatar */}
            <div
              className="w-32 h-32 rounded-full border-2 border-[oklch(0.78_0.14_85/0.5)] shrink-0 overflow-hidden"
              style={{ boxShadow: "0 0 30px oklch(0.78 0.14 85 / 0.3)" }}
            >
              {tarotista.imageUrl ? (
                <img src={tarotista.imageUrl} alt={tarotista.name} className="w-full h-full object-cover" />
              ) : (
                <div
                  className="w-full h-full flex items-center justify-center text-3xl font-bold"
                  style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.22 0.04 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}
                >
                  {tarotista.name.charAt(0)}
                </div>
              )}
            </div>

            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-3">
                <div>
                  <h1 className="text-3xl font-bold mb-1" style={{
                    fontFamily: "'Cinzel', serif",
                    background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
                  }}>
                    {tarotista.name}
                  </h1>
                  <p className="text-[oklch(0.65_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                    {tarotista.tagline}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                    {parseFloat(tarotista.pricePerSession ?? "25").toFixed(0)}€
                  </div>
                  <div className="text-xs text-[oklch(0.55_0.03_85)]">por sesión</div>
                </div>
              </div>

              <div className="flex items-center gap-3 mb-4">
                <StarRating rating={parseFloat(tarotista.rating ?? "5")} />
                <span className="text-sm text-[oklch(0.60_0.03_85)]">
                  {parseFloat(tarotista.rating ?? "5").toFixed(1)} ({tarotista.reviewCount} reseñas)
                </span>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="outline" className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.05)]">
                  {tarotista.specialty}
                </Badge>
                <Badge variant="outline" className="border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.65_0.03_85)]">
                  {arcanaLabel}
                </Badge>
                <Badge variant="outline" className={`${tarotista.available ? "border-green-500/40 text-green-400" : "border-red-500/30 text-red-400"}`}>
                  {tarotista.available ? "Disponible" : "Ocupada"}
                </Badge>
              </div>

              <div className="grid grid-cols-3 gap-4 text-center mb-4">
                {[
                  { label: "Años de experiencia", value: tarotista.experience },
                  { label: "Consultas realizadas", value: tarotista.totalConsultations?.toLocaleString() },
                  { label: "Valoración media", value: `${parseFloat(tarotista.rating ?? "5").toFixed(1)}★` },
                ].map((s) => (
                  <div key={s.label} className="p-3 rounded-lg bg-[oklch(0.13_0.01_285)] border border-[oklch(0.78_0.14_85/0.1)]">
                    <div className="text-lg font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                      {s.value}
                    </div>
                    <div className="text-xs text-[oklch(0.50_0.03_85)] mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-wrap gap-3">
                <Button
                  asChild
                  className="flex-1 min-w-32"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                    color: "oklch(0.08 0.005 285)",
                    fontFamily: "'Cinzel', serif",
                    letterSpacing: "0.1em",
                    fontSize: "0.75rem",
                  }}
                >
                  <Link href={isAuthenticated ? `/consulta/${tarotista.id}` : getLoginUrl()}>
                    <MessageCircle className="w-4 h-4 mr-2" /> Consultar Ahora
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="flex-1 min-w-32 border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]"
                  style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em", fontSize: "0.75rem" }}
                >
                  <Link href={`/reservas?tarotistaId=${tarotista.id}`}>
                    <Calendar className="w-4 h-4 mr-2" /> Reservar Cita
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Bio */}
        {tarotista.bio && (
          <div className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)] mb-8">
            <h2 className="text-lg font-bold mb-4" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Sobre {tarotista.name}
            </h2>
            <p className="text-[oklch(0.70_0.03_85)] leading-relaxed" style={{ fontFamily: "'EB Garamond', serif", fontSize: "1.05rem" }}>
              {tarotista.bio}
            </p>
          </div>
        )}

        {/* Reviews */}
        <div className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)]">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Reseñas ({resenas?.length ?? 0})
            </h2>
            {isAuthenticated && !showReviewForm && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowReviewForm(true)}
                className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] text-xs"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                <Star className="w-3.5 h-3.5 mr-1.5" /> Escribir Reseña
              </Button>
            )}
          </div>

          {showReviewForm && (
            <div className="p-5 rounded-lg border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.12_0.01_285)] mb-6">
              <h3 className="text-sm font-semibold mb-4" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                Tu Reseña
              </h3>
              <div className="mb-4">
                <p className="text-xs text-[oklch(0.60_0.03_85)] mb-2">Valoración</p>
                <StarRating rating={reviewRating} interactive onRate={setReviewRating} />
              </div>
              <input
                placeholder="Título (opcional)"
                value={reviewTitle}
                onChange={(e) => setReviewTitle(e.target.value)}
                className="w-full px-3 py-2 mb-3 rounded-md bg-[oklch(0.14_0.01_285)] border border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.90_0.03_85)] placeholder:text-[oklch(0.45_0.03_85)] text-sm focus:outline-none focus:border-[oklch(0.78_0.14_85)]"
              />
              <Textarea
                placeholder="Comparte tu experiencia..."
                value={reviewContent}
                onChange={(e) => setReviewContent(e.target.value)}
                className="mb-4 bg-[oklch(0.14_0.01_285)] border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.90_0.03_85)] placeholder:text-[oklch(0.45_0.03_85)] focus:border-[oklch(0.78_0.14_85)]"
                rows={3}
              />
              <div className="flex gap-3">
                <Button
                  onClick={() => createResena.mutate({ tarotistaId: tarotista.id, rating: reviewRating, title: reviewTitle || undefined, content: reviewContent || undefined })}
                  disabled={createResena.isPending}
                  className="text-xs"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                    color: "oklch(0.08 0.005 285)",
                    fontFamily: "'Cinzel', serif",
                  }}
                >
                  {createResena.isPending ? "Enviando..." : "Enviar Reseña"}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setShowReviewForm(false)} className="text-[oklch(0.60_0.03_85)] text-xs">
                  Cancelar
                </Button>
              </div>
            </div>
          )}

          {resenas && resenas.length > 0 ? (
            <div className="space-y-4">
              {resenas.map((r) => (
                <div key={r.id} className="p-4 rounded-lg border border-[oklch(0.78_0.14_85/0.1)] bg-[oklch(0.12_0.01_285)]">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <StarRating rating={r.rating} />
                      {r.title && (
                        <p className="text-sm font-semibold mt-1 text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                          {r.title}
                        </p>
                      )}
                    </div>
                    <span className="text-xs text-[oklch(0.45_0.03_85)]">
                      {new Date(r.createdAt).toLocaleDateString("es-ES")}
                    </span>
                  </div>
                  {r.content && (
                    <p className="text-sm text-[oklch(0.65_0.03_85)] italic leading-relaxed" style={{ fontFamily: "'EB Garamond', serif" }}>
                      "{r.content}"
                    </p>
                  )}
                  <p className="text-xs text-[oklch(0.50_0.03_85)] mt-2">— {r.userName ?? "Usuaria anónima"}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Sparkles className="w-8 h-8 mx-auto mb-3 text-[oklch(0.78_0.14_85/0.3)]" />
              <p className="text-sm text-[oklch(0.50_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                Aún no hay reseñas. ¡Sé la primera en compartir tu experiencia!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
