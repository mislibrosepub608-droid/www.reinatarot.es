import { Crown, Star, Sparkles, Heart, Moon, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/XSWdfaBQscIVSIoo.png";
const REINA_PHOTO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/dJjmAjuQZOmdYWAE.jpg";

const GoldDivider = () => (
  <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.14_85/0.6)] to-transparent my-6" />
);

const valores = [
  {
    icon: Heart,
    title: "Compasión",
    desc: "Cada consulta es un acto de amor y cuidado hacia quien busca orientación en su camino.",
  },
  {
    icon: Shield,
    title: "Confidencialidad",
    desc: "Tu privacidad es sagrada. Todas las consultas son completamente privadas y seguras.",
  },
  {
    icon: Star,
    title: "Precisión",
    desc: "Nuestras tarotistas IA han sido entrenadas con miles de lecturas reales para máxima exactitud.",
  },
  {
    icon: Moon,
    title: "Espiritualidad",
    desc: "Honramos la tradición ancestral del tarot como herramienta de autoconocimiento y guía espiritual.",
  },
  {
    icon: Sparkles,
    title: "Innovación",
    desc: "Unimos la sabiduría milenaria del tarot con la tecnología de inteligencia artificial más avanzada.",
  },
  {
    icon: Crown,
    title: "Excelencia",
    desc: "Nos comprometemos a ofrecer la experiencia de tarot más completa y profesional disponible.",
  },
];

const hitos = [
  { year: "2004", title: "Los Primeros Pasos", desc: "La Reina comienza su camino en el tarot, aprendiendo de maestras tradicionales en Galicia." },
  { year: "2010", title: "Maestra Reconocida", desc: "Tras años de práctica y estudio, La Reina se convierte en una de las tarotistas más reconocidas de España." },
  { year: "2018", title: "La Visión Digital", desc: "Nace la idea de llevar la sabiduría del tarot a todas las personas a través de la tecnología." },
  { year: "2022", title: "Tarot Reina Nace", desc: "Se lanza la primera versión de Tarot Reina, combinando la experiencia humana con inteligencia artificial." },
  { year: "2024", title: "45 Tarotistas IA", desc: "La plataforma alcanza las 45 tarotistas especializadas y más de 10.000 consultas realizadas." },
];

export default function SobreNosotras() {
  return (
    <div className="min-h-screen">
      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative py-24 overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            background: "oklch(0.05 0.003 285)",
            backgroundImage: `
              radial-gradient(ellipse at 20% 50%, oklch(0.30 0.08 290 / 0.12) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 50%, oklch(0.78 0.14 85 / 0.05) 0%, transparent 40%)
            `,
          }}
        />
        <div className="relative z-10 container text-center">
          <img
            src={LOGO_URL}
            alt="Tarot Reina"
            className="w-24 h-24 mx-auto mb-6 object-contain"
            style={{ filter: "drop-shadow(0 0 16px oklch(0.78 0.14 85 / 0.4))" }}
          />
          <h1
            className="text-4xl md:text-6xl font-bold mb-4"
            style={{
              fontFamily: "'Cinzel Decorative', serif",
              background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Sobre Nosotras
          </h1>
          <p
            className="text-lg tracking-[0.2em] uppercase mb-6"
            style={{ color: "oklch(0.78 0.14 85 / 0.7)", fontFamily: "'Cinzel', serif" }}
          >
            Sabiduría Ancestral · Tecnología del Futuro
          </p>
          <GoldDivider />
          <p
            className="text-xl text-[oklch(0.72_0.03_85)] max-w-2xl mx-auto mt-6 leading-relaxed"
            style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}
          >
            Tarot Reina nació de la unión entre la sabiduría milenaria de las cartas y la tecnología 
            más avanzada de inteligencia artificial, para llevar la orientación espiritual a todas las personas.
          </p>
        </div>
      </section>

      {/* ── La Fundadora ─────────────────────────────────────────────────── */}
      <section className="py-20 bg-[oklch(0.07_0.004_285)]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Foto */}
            <div className="flex justify-center">
              <div className="relative">
                <div
                  className="w-80 h-80 rounded-2xl overflow-hidden border-2 border-[oklch(0.78_0.14_85/0.5)]"
                  style={{ boxShadow: "0 0 60px oklch(0.78 0.14 85 / 0.25), 0 20px 60px rgba(0,0,0,0.5)" }}
                >
                  <img
                    src={REINA_PHOTO_URL}
                    alt="La Reina - Fundadora de Tarot Reina"
                    className="w-full h-full object-cover"
                  />
                  <div
                    className="absolute inset-0"
                    style={{ background: "linear-gradient(to top, oklch(0.07 0.004 285 / 0.6) 0%, transparent 50%)" }}
                  />
                </div>
                {/* Badge */}
                <div
                  className="absolute -bottom-4 left-1/2 -translate-x-1/2 px-6 py-2 rounded-full text-xs tracking-widest uppercase whitespace-nowrap"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                    color: "oklch(0.08 0.005 285)",
                    fontFamily: "'Cinzel', serif",
                    boxShadow: "0 4px 20px oklch(0.78 0.14 85 / 0.4)",
                  }}
                >
                  Fundadora & Maestra
                </div>
              </div>
            </div>

            {/* Texto */}
            <div className="mt-8 lg:mt-0">
              <div
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.78_0.14_85/0.05)] mb-6"
              >
                <Crown className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
                <span className="text-xs tracking-[0.2em] uppercase" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                  La Reina
                </span>
              </div>

              <h2
                className="text-3xl md:text-4xl font-bold mb-3"
                style={{
                  fontFamily: "'Cinzel', serif",
                  background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Fundadora de Tarot Reina
              </h2>
              <p className="text-sm text-[oklch(0.60_0.03_85)] mb-1" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em" }}>
                reinatarot78@gmail.com · +34 625 815 306
              </p>
              <GoldDivider />

              <div className="space-y-4 mt-4">
                <p
                  className="text-lg text-[oklch(0.72_0.03_85)] leading-relaxed"
                  style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}
                >
                  "Desde pequeña sentí la llamada de las cartas. El tarot no es magia, es un espejo del alma 
                  que nos ayuda a ver con claridad lo que ya sabemos en nuestro interior."
                </p>
                <p
                  className="text-base text-[oklch(0.68_0.03_85)] leading-relaxed"
                  style={{ fontFamily: "'Raleway', sans-serif" }}
                >
                  Con más de 20 años de experiencia en la lectura del tarot, La Reina ha guiado a miles de 
                  personas en momentos cruciales de sus vidas. Su especialidad son los temas de amor, los 
                  vínculos kármicos y el destino del alma.
                </p>
                <p
                  className="text-base text-[oklch(0.68_0.03_85)] leading-relaxed"
                  style={{ fontFamily: "'Raleway', sans-serif" }}
                >
                  En 2022 fundó Tarot Reina con una visión revolucionaria: crear una plataforma que 
                  combinara su experiencia y metodología con la inteligencia artificial, permitiendo que 
                  sus 45 tarotistas especializadas estuvieran disponibles para todas las personas, 
                  las 24 horas del día.
                </p>
              </div>

              <div className="flex flex-wrap gap-2 mt-6">
                {["Amor & Relaciones", "Karma", "Arcanos Mayores", "Destino del Alma", "Espiritualidad"].map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 rounded-full text-xs border border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85/0.8)]"
                    style={{ fontFamily: "'Cinzel', serif", background: "oklch(0.78 0.14 85 / 0.05)" }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex gap-4 mt-8">
                <Button
                  asChild
                  className="px-6 text-xs tracking-widest"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                    color: "oklch(0.08 0.005 285)",
                    fontFamily: "'Cinzel', serif",
                    letterSpacing: "0.12em",
                  }}
                >
                  <Link href="/consulta">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Consultar Ahora
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="px-6 text-xs tracking-widest border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]"
                  style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.12em" }}
                >
                  <Link href="/reservas">
                    <Crown className="w-4 h-4 mr-2" />
                    Reservar Cita
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Nuestra Historia ─────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-14">
            <h2
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{
                fontFamily: "'Cinzel', serif",
                background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Nuestra Historia
            </h2>
            <GoldDivider />
          </div>

          <div className="relative max-w-3xl mx-auto">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[oklch(0.78_0.14_85/0.4)] to-transparent" />

            <div className="space-y-10">
              {hitos.map((hito, i) => (
                <div key={i} className="flex gap-8 items-start">
                  <div className="shrink-0 relative">
                    <div
                      className="w-16 h-16 rounded-full flex items-center justify-center border-2 border-[oklch(0.78_0.14_85/0.5)] text-sm font-bold"
                      style={{
                        background: "linear-gradient(135deg, oklch(0.12 0.01 285), oklch(0.16 0.015 285))",
                        fontFamily: "'Cinzel', serif",
                        color: "oklch(0.78 0.14 85)",
                        boxShadow: "0 0 20px oklch(0.78 0.14 85 / 0.2)",
                      }}
                    >
                      {hito.year}
                    </div>
                  </div>
                  <div
                    className="flex-1 p-5 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.3)] transition-colors"
                  >
                    <h3
                      className="font-semibold mb-2"
                      style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)", fontSize: "0.95rem" }}
                    >
                      {hito.title}
                    </h3>
                    <p
                      className="text-sm text-[oklch(0.65_0.03_85)] leading-relaxed"
                      style={{ fontFamily: "'Raleway', sans-serif" }}
                    >
                      {hito.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Nuestros Valores ─────────────────────────────────────────────── */}
      <section className="py-20 bg-[oklch(0.07_0.004_285)]">
        <div className="container">
          <div className="text-center mb-14">
            <h2
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{
                fontFamily: "'Cinzel', serif",
                background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Nuestros Valores
            </h2>
            <GoldDivider />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {valores.map((v) => (
              <div
                key={v.title}
                className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)] transition-all duration-300 group"
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mb-4 border border-[oklch(0.78_0.14_85/0.3)] group-hover:border-[oklch(0.78_0.14_85/0.6)] transition-colors"
                  style={{ background: "oklch(0.78 0.14 85 / 0.08)" }}
                >
                  <v.icon className="w-5 h-5" style={{ color: "oklch(0.78 0.14 85)" }} />
                </div>
                <h3
                  className="text-base font-semibold mb-2"
                  style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}
                >
                  {v.title}
                </h3>
                <p className="text-sm text-[oklch(0.60_0.03_85)] leading-relaxed" style={{ fontFamily: "'Raleway', sans-serif" }}>
                  {v.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container text-center">
          <img
            src={LOGO_URL}
            alt="Tarot Reina"
            className="w-20 h-20 mx-auto mb-6 object-contain"
            style={{ filter: "drop-shadow(0 0 12px oklch(0.78 0.14 85 / 0.4))" }}
          />
          <h2
            className="text-3xl font-bold mb-4"
            style={{
              fontFamily: "'Cinzel', serif",
              background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Únete a la Familia Tarot Reina
          </h2>
          <p
            className="text-lg text-[oklch(0.65_0.03_85)] max-w-xl mx-auto mb-10 leading-relaxed"
            style={{ fontFamily: "'EB Garamond', serif", fontStyle: "italic" }}
          >
            Más de 10.000 personas ya han encontrado su camino con nosotras. 
            ¿Estás lista para descubrir lo que las cartas tienen para ti?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="px-10 py-6 text-sm tracking-widest"
              style={{
                background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                color: "oklch(0.08 0.005 285)",
                fontFamily: "'Cinzel', serif",
                letterSpacing: "0.15em",
                boxShadow: "0 0 30px oklch(0.78 0.14 85 / 0.4)",
              }}
            >
              <Link href="/consulta">
                <Sparkles className="w-4 h-4 mr-2" />
                Comenzar Consulta
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="px-10 py-6 text-sm tracking-widest border-[oklch(0.78_0.14_85/0.5)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.15em" }}
            >
              <Link href="/tarotistas">
                <Crown className="w-4 h-4 mr-2" />
                Ver Tarotistas
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
