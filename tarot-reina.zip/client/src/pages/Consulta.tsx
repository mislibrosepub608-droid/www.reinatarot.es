import { useState, useRef, useEffect } from "react";
import { useParams, Link } from "wouter";
import { Send, Crown, Sparkles, Plus, MessageCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Streamdown } from "streamdown";

export default function Consulta() {
  const params = useParams<{ tarotistaId?: string }>();
  const { isAuthenticated, user } = useAuth();
  const [selectedTarotistaId, setSelectedTarotistaId] = useState<number | null>(
    params.tarotistaId ? parseInt(params.tarotistaId) : null
  );
  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const [localMessages, setLocalMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();

  const { data: tarotistas } = trpc.tarotistas.list.useQuery({ limit: 45 });
  const { data: sessions, refetch: refetchSessions } = trpc.chat.getSessions.useQuery(undefined, { enabled: isAuthenticated });
  const { data: sessionMessages } = trpc.chat.getMessages.useQuery(
    { sessionId: activeSessionId! },
    { enabled: !!activeSessionId }
  );

  const createSession = trpc.chat.createSession.useMutation({
    onSuccess: async () => {
      await refetchSessions();
      const updated = await utils.chat.getSessions.fetch();
      if (updated.length > 0) setActiveSessionId(updated[0].id);
    },
  });

  const sendMessage = trpc.chat.sendMessage.useMutation({
    onMutate: ({ message: msg }) => {
      setLocalMessages((prev) => [...prev, { role: "user", content: msg }]);
      setMessage("");
      setIsTyping(true);
    },
    onSuccess: (data) => {
      setLocalMessages((prev) => [...prev, { role: "assistant", content: data.content }]);
      setIsTyping(false);
    },
    onError: () => setIsTyping(false),
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [localMessages, isTyping]);

  useEffect(() => {
    if (sessionMessages) {
      setLocalMessages(sessionMessages.map((m) => ({ role: m.role as "user" | "assistant", content: String(m.content) })));
    }
  }, [sessionMessages]);

  const selectedTarotista = tarotistas?.tarotistas.find((t) => t.id === selectedTarotistaId);

  const handleStartSession = async () => {
    if (!selectedTarotistaId) return;
    await createSession.mutateAsync({ tarotistaId: selectedTarotistaId });
  };

  const handleSend = () => {
    if (!message.trim() || !activeSessionId || sendMessage.isPending) return;
    sendMessage.mutate({ sessionId: activeSessionId, message: message.trim() });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md p-8 rounded-2xl border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.10_0.007_285)]">
          <Crown className="w-16 h-16 mx-auto mb-6" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
          <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
            Inicia Sesión para Consultar
          </h2>
          <p className="text-[oklch(0.60_0.03_85)] mb-6 italic" style={{ fontFamily: "'EB Garamond', serif" }}>
            Para acceder a las consultas de tarot con IA, necesitas una cuenta en Tarot Reina.
          </p>
          <Button asChild style={{
            background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
            color: "oklch(0.08 0.005 285)",
            fontFamily: "'Cinzel', serif",
            letterSpacing: "0.1em",
          }}>
            <a href={getLoginUrl()}>
              <Sparkles className="w-4 h-4 mr-2" /> Iniciar Sesión
            </a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex" style={{ height: "calc(100vh - 64px)" }}>
      {/* Sidebar: Sessions + Tarotistas */}
      <div className="w-72 shrink-0 border-r border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.09_0.006_285)] flex flex-col hidden md:flex">
        <div className="p-4 border-b border-[oklch(0.78_0.14_85/0.15)]">
          <h2 className="text-sm font-bold tracking-widest" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
            Consultas
          </h2>
        </div>

        {/* New Session */}
        <div className="p-3 border-b border-[oklch(0.78_0.14_85/0.1)]">
          <Button
            onClick={() => { setActiveSessionId(null); setLocalMessages([]); setSelectedTarotistaId(null); }}
            variant="outline"
            size="sm"
            className="w-full border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)] text-xs"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            <Plus className="w-3.5 h-3.5 mr-1.5" /> Nueva Consulta
          </Button>
        </div>

        {/* Sessions list */}
        <div className="flex-1 overflow-y-auto p-2">
          {sessions?.map((s) => (
            <button
              key={s.id}
              onClick={() => { setActiveSessionId(s.id); setLocalMessages([]); }}
              className={`w-full text-left p-3 rounded-lg mb-1 transition-colors text-xs ${
                activeSessionId === s.id
                  ? "bg-[oklch(0.78_0.14_85/0.15)] text-[oklch(0.88_0.05_85)]"
                  : "text-[oklch(0.60_0.03_85)] hover:bg-[oklch(0.78_0.14_85/0.05)] hover:text-[oklch(0.78_0.14_85)]"
              }`}
            >
              <div className="flex items-center gap-2">
                <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{String(s.title)}</span>
              </div>
              <div className="text-[oklch(0.40_0.02_85)] mt-0.5 pl-5">
                {new Date(s.updatedAt).toLocaleDateString("es-ES")}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {!activeSessionId ? (
          /* Tarotista Selection */
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-8">
                <Crown className="w-12 h-12 mx-auto mb-4" style={{ color: "oklch(0.78 0.14 85)" }} fill="oklch(0.78 0.14 85)" />
                <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
                  Elige tu Tarotista
                </h2>
                <p className="text-[oklch(0.60_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                  Selecciona la maestra que guiará tu consulta
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                {tarotistas?.tarotistas.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setSelectedTarotistaId(t.id)}
                    className={`p-4 rounded-xl border text-left transition-all duration-200 ${
                      selectedTarotistaId === t.id
                        ? "border-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.1)] shadow-[0_0_20px_oklch(0.78_0.14_85/0.2)]"
                        : "border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)]"
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-full border border-[oklch(0.78_0.14_85/0.4)] shrink-0 overflow-hidden">
                        {t.imageUrl ? (
                          <img src={t.imageUrl} alt={t.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-base font-bold" style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>{t.name.charAt(0)}</div>
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)] truncate" style={{ fontFamily: "'Cinzel', serif" }}>
                          {t.name}
                        </div>
                        <div className="text-xs text-[oklch(0.55_0.03_85)] truncate">{t.specialty}</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className={`text-xs ${t.available ? "border-green-500/30 text-green-400" : "border-red-500/30 text-red-400"}`}>
                        {t.available ? "Disponible" : "Ocupada"}
                      </Badge>
                      <span className="text-xs font-bold" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                        {parseFloat(t.pricePerSession ?? "25").toFixed(0)}€
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              {selectedTarotistaId && (
                <div className="text-center">
                  <Button
                    onClick={handleStartSession}
                    disabled={createSession.isPending}
                    size="lg"
                    className="px-10"
                    style={{
                      background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                      color: "oklch(0.08 0.005 285)",
                      fontFamily: "'Cinzel', serif",
                      letterSpacing: "0.1em",
                      boxShadow: "0 0 20px oklch(0.78 0.14 85 / 0.3)",
                    }}
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    {createSession.isPending ? "Iniciando..." : `Consultar con ${selectedTarotista?.name}`}
                  </Button>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Chat Interface */
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.09_0.006_285)] flex items-center gap-3">
              <button onClick={() => { setActiveSessionId(null); setLocalMessages([]); }} className="text-[oklch(0.60_0.03_85)] hover:text-[oklch(0.78_0.14_85)] transition-colors">
                <ArrowLeft className="w-4 h-4" />
              </button>
              {selectedTarotista && (
                <>
                  <div className="w-8 h-8 rounded-full border border-[oklch(0.78_0.14_85/0.4)] overflow-hidden shrink-0">
                    {selectedTarotista.imageUrl ? (
                      <img src={selectedTarotista.imageUrl} alt={selectedTarotista.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-sm font-bold" style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>{selectedTarotista.name.charAt(0)}</div>
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                      {selectedTarotista.name}
                    </div>
                    <div className="text-xs text-[oklch(0.55_0.03_85)]">{selectedTarotista.specialty}</div>
                  </div>
                </>
              )}
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {localMessages.length === 0 && (
                <div className="text-center py-12">
                  <Sparkles className="w-10 h-10 mx-auto mb-4 text-[oklch(0.78_0.14_85/0.4)]" />
                  <p className="text-[oklch(0.55_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                    Las cartas aguardan tu pregunta...
                  </p>
                </div>
              )}
              {localMessages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  {msg.role === "assistant" && (
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border border-[oklch(0.78_0.14_85/0.4)] mr-2 shrink-0 mt-1"
                      style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                      ✦
                    </div>
                  )}
                  <div
                    className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-[oklch(0.78_0.14_85/0.15)] text-[oklch(0.90_0.03_85)] border border-[oklch(0.78_0.14_85/0.3)]"
                        : "bg-[oklch(0.12_0.01_285)] text-[oklch(0.85_0.03_85)] border border-[oklch(0.78_0.14_85/0.1)]"
                    }`}
                    style={{ fontFamily: msg.role === "assistant" ? "'EB Garamond', serif" : "'Raleway', sans-serif" }}
                  >
                    {msg.role === "assistant" ? <Streamdown>{msg.content}</Streamdown> : msg.content}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border border-[oklch(0.78_0.14_85/0.4)] mr-2 shrink-0"
                    style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", color: "oklch(0.78 0.14 85)" }}>
                    ✦
                  </div>
                  <div className="bg-[oklch(0.12_0.01_285)] border border-[oklch(0.78_0.14_85/0.1)] rounded-2xl px-4 py-3">
                    <div className="flex gap-1">
                      {[0, 1, 2].map((i) => (
                        <div key={i} className="w-2 h-2 rounded-full bg-[oklch(0.78_0.14_85/0.6)] animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.09_0.006_285)]">
              <div className="flex gap-3 items-end">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Escribe tu pregunta a las cartas..."
                  rows={2}
                  className="flex-1 bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] placeholder:text-[oklch(0.40_0.02_85)] focus:border-[oklch(0.78_0.14_85)] resize-none"
                  style={{ fontFamily: "'Raleway', sans-serif" }}
                />
                <Button
                  onClick={handleSend}
                  disabled={!message.trim() || sendMessage.isPending}
                  className="h-[52px] w-12 p-0 shrink-0"
                  style={{
                    background: message.trim() ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))" : "oklch(0.16 0.015 285)",
                    color: message.trim() ? "oklch(0.08 0.005 285)" : "oklch(0.45 0.03 85)",
                  }}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-[oklch(0.40_0.02_85)] mt-2 text-center">Enter para enviar · Shift+Enter para nueva línea</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
