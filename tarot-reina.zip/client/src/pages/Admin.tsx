import { useState } from "react";
import { Crown, Users, Calendar, Star, BarChart3, CheckCircle, XCircle, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Link } from "wouter";
import { toast } from "sonner";

type AdminTab = "dashboard" | "tarotistas" | "reservas" | "resenas" | "usuarios";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>("dashboard");

  const { data: stats } = trpc.admin.stats.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const { data: tarotistas } = trpc.tarotistas.list.useQuery({ limit: 50 }, { enabled: activeTab === "tarotistas" });
  const { data: reservas } = trpc.reservas.all.useQuery(undefined, { enabled: activeTab === "reservas" && user?.role === "admin" });
  const { data: resenas } = trpc.resenas.all.useQuery(undefined, { enabled: activeTab === "resenas" && user?.role === "admin" });
  const { data: usuarios } = trpc.admin.users.useQuery(undefined, { enabled: activeTab === "usuarios" && user?.role === "admin" });

  const utils = trpc.useUtils();

  const approveResena = trpc.resenas.approve.useMutation({
    onSuccess: () => { toast.success("Reseña aprobada"); utils.resenas.all.invalidate(); },
  });
  const updateReserva = trpc.reservas.updateStatus.useMutation({
    onSuccess: () => { toast.success("Estado actualizado"); utils.reservas.all.invalidate(); },
  });
  const updateTarotista = trpc.tarotistas.update.useMutation({
    onSuccess: () => { toast.success("Tarotista actualizada"); utils.tarotistas.list.invalidate(); },
  });

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center p-8 rounded-2xl border border-red-500/30 bg-red-500/5 max-w-md">
          <XCircle className="w-12 h-12 mx-auto mb-4 text-red-400" />
          <h2 className="text-xl font-bold mb-2 text-red-400" style={{ fontFamily: "'Cinzel', serif" }}>Acceso Denegado</h2>
          <p className="text-[oklch(0.60_0.03_85)] mb-4">Solo los administradores pueden acceder a este panel.</p>
          <Button asChild variant="outline" className="border-[oklch(0.78_0.14_85/0.4)] text-[oklch(0.78_0.14_85)]">
            <Link href="/">Volver al Inicio</Link>
          </Button>
        </div>
      </div>
    );
  }

  const tabs: { id: AdminTab; label: string; icon: typeof Crown }[] = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3 },
    { id: "tarotistas", label: "Tarotistas", icon: Crown },
    { id: "reservas", label: "Reservas", icon: Calendar },
    { id: "resenas", label: "Reseñas", icon: Star },
    { id: "usuarios", label: "Usuarios", icon: Users },
  ];

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold" style={{
              fontFamily: "'Cinzel', serif",
              background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
            }}>
              Panel de Administración
            </h1>
            <p className="text-sm text-[oklch(0.55_0.03_85)] mt-1">Tarot Reina · Gestión completa</p>
          </div>
          <Settings className="w-6 h-6" style={{ color: "oklch(0.78 0.14 85)" }} />
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-8 p-1 rounded-xl bg-[oklch(0.10_0.007_285)] border border-[oklch(0.78_0.14_85/0.15)] overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold tracking-wider transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-[oklch(0.78_0.14_85/0.15)] text-[oklch(0.78_0.14_85)] border border-[oklch(0.78_0.14_85/0.4)]"
                  : "text-[oklch(0.60_0.03_85)] hover:text-[oklch(0.78_0.14_85)]"
              }`}
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Dashboard */}
        {activeTab === "dashboard" && (
          <div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {[
                { label: "Tarotistas", value: stats?.tarotistas ?? 0, icon: Crown, color: "oklch(0.78 0.14 85)" },
                { label: "Usuarios", value: stats?.users ?? 0, icon: Users, color: "oklch(0.65 0.15 260)" },
                { label: "Reservas", value: stats?.reservas ?? 0, icon: Calendar, color: "oklch(0.65 0.15 160)" },
                { label: "Reseñas", value: stats?.resenas ?? 0, icon: Star, color: "oklch(0.65 0.15 40)" },
              ].map((s) => (
                <div key={s.label} className="p-5 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)]">
                  <s.icon className="w-6 h-6 mb-3" style={{ color: s.color }} />
                  <div className="text-3xl font-bold mb-1" style={{ fontFamily: "'Cinzel', serif", color: s.color }}>
                    {s.value}
                  </div>
                  <div className="text-xs text-[oklch(0.55_0.03_85)]">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="p-6 rounded-xl border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)]">
              <h3 className="text-sm font-bold mb-4" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                Acciones Rápidas
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {tabs.slice(1).map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className="p-4 rounded-lg border border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.12_0.01_285)] hover:border-[oklch(0.78_0.14_85/0.5)] transition-colors text-center"
                  >
                    <tab.icon className="w-5 h-5 mx-auto mb-2" style={{ color: "oklch(0.78 0.14 85)" }} />
                    <span className="text-xs text-[oklch(0.70_0.03_85)]" style={{ fontFamily: "'Cinzel', serif" }}>{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tarotistas */}
        {activeTab === "tarotistas" && (
          <div>
            <h2 className="text-lg font-bold mb-5" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Gestión de Tarotistas ({tarotistas?.total ?? 0})
            </h2>
            <div className="space-y-3">
              {tarotistas?.tarotistas.map((t) => (
                <div key={t.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold border border-[oklch(0.78_0.14_85/0.4)] shrink-0"
                      style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>{t.name}</div>
                      <div className="text-xs text-[oklch(0.55_0.03_85)]">{t.specialty} · {parseFloat(t.pricePerSession ?? "25").toFixed(0)}€</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className={`text-xs ${t.available ? "border-green-500/40 text-green-400" : "border-red-500/30 text-red-400"}`}>
                      {t.available ? "Disponible" : "No disponible"}
                    </Badge>
                    <Badge variant="outline" className={`text-xs ${t.featured ? "border-[oklch(0.78_0.14_85/0.5)] text-[oklch(0.78_0.14_85)]" : "border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.50_0.03_85)]"}`}>
                      {t.featured ? "Destacada" : "Normal"}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => updateTarotista.mutate({ id: t.id, available: !t.available })}
                      className="text-xs text-[oklch(0.60_0.03_85)] hover:text-[oklch(0.78_0.14_85)]"
                    >
                      {t.available ? "Desactivar" : "Activar"}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => updateTarotista.mutate({ id: t.id, featured: !t.featured })}
                      className="text-xs text-[oklch(0.60_0.03_85)] hover:text-[oklch(0.78_0.14_85)]"
                    >
                      {t.featured ? "Quitar Destaque" : "Destacar"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reservas */}
        {activeTab === "reservas" && (
          <div>
            <h2 className="text-lg font-bold mb-5" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Gestión de Reservas
            </h2>
            <div className="space-y-3">
              {reservas?.map((r) => (
                <div key={r.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)]">
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <div>
                      <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                        {new Date(r.scheduledAt).toLocaleString("es-ES", { dateStyle: "medium", timeStyle: "short" })}
                      </div>
                      <div className="text-xs text-[oklch(0.55_0.03_85)] mt-0.5">
                        {r.guestName ?? "Usuario registrado"} · {r.consultationType} · {r.duration}min · {parseFloat(r.price ?? "0").toFixed(0)}€
                      </div>
                      {r.question && (
                        <div className="text-xs text-[oklch(0.50_0.03_85)] mt-1 italic">"{String(r.question).substring(0, 80)}..."</div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={`text-xs ${
                        r.status === "confirmed" ? "border-green-500/40 text-green-400" :
                        r.status === "completed" ? "border-blue-500/40 text-blue-400" :
                        r.status === "cancelled" ? "border-red-500/40 text-red-400" :
                        "border-yellow-500/40 text-yellow-400"
                      }`}>
                        {r.status}
                      </Badge>
                      {r.status === "pending" && (
                        <>
                          <Button size="sm" variant="ghost" onClick={() => updateReserva.mutate({ id: r.id, status: "confirmed" })}
                            className="text-xs text-green-400 hover:text-green-300">
                            <CheckCircle className="w-3.5 h-3.5 mr-1" /> Confirmar
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => updateReserva.mutate({ id: r.id, status: "cancelled" })}
                            className="text-xs text-red-400 hover:text-red-300">
                            <XCircle className="w-3.5 h-3.5 mr-1" /> Cancelar
                          </Button>
                        </>
                      )}
                      {r.status === "confirmed" && (
                        <Button size="sm" variant="ghost" onClick={() => updateReserva.mutate({ id: r.id, status: "completed" })}
                          className="text-xs text-blue-400 hover:text-blue-300">
                          Completar
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              {(!reservas || reservas.length === 0) && (
                <div className="text-center py-8 text-[oklch(0.50_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                  No hay reservas registradas.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Reseñas */}
        {activeTab === "resenas" && (
          <div>
            <h2 className="text-lg font-bold mb-5" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Moderación de Reseñas
            </h2>
            <div className="space-y-3">
              {resenas?.map((r) => (
                <div key={r.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)]">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="flex gap-0.5">
                          {[1,2,3,4,5].map((i) => (
                            <Star key={i} className="w-3 h-3" style={{ color: "oklch(0.78 0.14 85)" }} fill={i <= r.rating ? "oklch(0.78 0.14 85)" : "transparent"} />
                          ))}
                        </div>
                        <span className="text-xs text-[oklch(0.55_0.03_85)]">— {r.userName ?? "Anónima"}</span>
                        <span className="text-xs text-[oklch(0.45_0.03_85)]">para {r.tarotistaName}</span>
                      </div>
                      {r.title && <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)] mb-1" style={{ fontFamily: "'Cinzel', serif" }}>{r.title}</div>}
                      {r.content && <div className="text-sm text-[oklch(0.65_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>"{r.content}"</div>}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge variant="outline" className={`text-xs ${r.approved ? "border-green-500/40 text-green-400" : "border-yellow-500/40 text-yellow-400"}`}>
                        {r.approved ? "Aprobada" : "Pendiente"}
                      </Badge>
                      {!r.approved && (
                        <Button size="sm" variant="ghost" onClick={() => approveResena.mutate({ id: r.id })}
                          className="text-xs text-green-400 hover:text-green-300">
                          <CheckCircle className="w-3.5 h-3.5 mr-1" /> Aprobar
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              {(!resenas || resenas.length === 0) && (
                <div className="text-center py-8 text-[oklch(0.50_0.03_85)] italic" style={{ fontFamily: "'EB Garamond', serif" }}>
                  No hay reseñas registradas.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Usuarios */}
        {activeTab === "usuarios" && (
          <div>
            <h2 className="text-lg font-bold mb-5" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Gestión de Usuarios ({usuarios?.length ?? 0})
            </h2>
            <div className="space-y-3">
              {usuarios?.map((u) => (
                <div key={u.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold border border-[oklch(0.78_0.14_85/0.3)]"
                      style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                      {(u.name ?? "U").charAt(0)}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)]">{u.name ?? "Sin nombre"}</div>
                      <div className="text-xs text-[oklch(0.50_0.03_85)]">{u.email ?? "Sin email"}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={`text-xs ${u.role === "admin" ? "border-[oklch(0.78_0.14_85/0.5)] text-[oklch(0.78_0.14_85)]" : "border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.55_0.03_85)]"}`}>
                      {u.role}
                    </Badge>
                    <span className="text-xs text-[oklch(0.45_0.03_85)]">
                      {new Date(u.createdAt).toLocaleDateString("es-ES")}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
