import { useState } from "react";
import { Calendar, Clock, Crown, CheckCircle, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

const consultationTypes = [
  { value: "chat", label: "Chat IA", desc: "Consulta por texto con tu tarotista" },
  { value: "video", label: "Videollamada", desc: "Sesión cara a cara por video" },
  { value: "phone", label: "Teléfono", desc: "Consulta por llamada telefónica" },
];

const durations = [
  { value: 30, label: "30 min" },
  { value: 45, label: "45 min" },
  { value: 60, label: "60 min" },
];

export default function Reservas() {
  const { isAuthenticated, user } = useAuth();
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  const [selectedTarotistaId, setSelectedTarotistaId] = useState<number | null>(null);
  const [consultationType, setConsultationType] = useState<"chat" | "video" | "phone">("chat");
  const [duration, setDuration] = useState(30);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [question, setQuestion] = useState("");
  const [guestName, setGuestName] = useState(user?.name ?? "");
  const [guestEmail, setGuestEmail] = useState(user?.email ?? "");
  const [guestPhone, setGuestPhone] = useState("");

  const { data: tarotistas } = trpc.tarotistas.list.useQuery({ limit: 45 });
  const { data: myReservas } = trpc.reservas.myReservas.useQuery(undefined, { enabled: isAuthenticated });

  const createReserva = trpc.reservas.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("¡Reserva realizada con éxito!");
    },
    onError: () => toast.error("Error al crear la reserva. Inténtalo de nuevo."),
  });

  const selectedTarotista = tarotistas?.tarotistas.find((t) => t.id === selectedTarotistaId);

  const handleSubmit = () => {
    if (!selectedTarotistaId || !date || !time) {
      toast.error("Por favor completa todos los campos requeridos");
      return;
    }
    const scheduledAt = new Date(`${date}T${time}`).toISOString();
    createReserva.mutate({
      tarotistaId: selectedTarotistaId,
      consultationType,
      duration,
      scheduledAt,
      question: question || undefined,
      guestName: !isAuthenticated ? guestName : undefined,
      guestEmail: !isAuthenticated ? guestEmail : undefined,
      guestPhone: !isAuthenticated ? guestPhone : undefined,
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center py-12">
        <div className="text-center max-w-md p-8 rounded-2xl border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.10_0.007_285)]">
          <CheckCircle className="w-16 h-16 mx-auto mb-6" style={{ color: "oklch(0.78 0.14 85)" }} />
          <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
            ¡Reserva Confirmada!
          </h2>
          <p className="text-[oklch(0.60_0.03_85)] mb-2 italic" style={{ fontFamily: "'EB Garamond', serif" }}>
            Tu cita con <strong style={{ color: "oklch(0.78 0.14 85)" }}>{selectedTarotista?.name}</strong> ha sido reservada.
          </p>
          <p className="text-sm text-[oklch(0.55_0.03_85)] mb-6">
            {new Date(`${date}T${time}`).toLocaleString("es-ES", { dateStyle: "full", timeStyle: "short" })}
          </p>
          <Button
            onClick={() => { setSubmitted(false); setStep(1); setSelectedTarotistaId(null); setDate(""); setTime(""); setQuestion(""); }}
            style={{
              background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
              color: "oklch(0.08 0.005 285)",
              fontFamily: "'Cinzel', serif",
              letterSpacing: "0.1em",
            }}
          >
            Nueva Reserva
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container max-w-4xl">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.78_0.14_85/0.05)] mb-6">
            <Calendar className="w-4 h-4" style={{ color: "oklch(0.78 0.14 85)" }} />
            <span className="text-xs tracking-[0.2em] uppercase" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
              Reserva tu Consulta
            </span>
          </div>
          <h1 className="text-4xl font-bold mb-4" style={{
            fontFamily: "'Cinzel', serif",
            background: "linear-gradient(135deg, oklch(0.88 0.10 85), oklch(0.78 0.14 85))",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
          }}>
            Reservas
          </h1>
          <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.78_0.14_85/0.6)] to-transparent max-w-xs mx-auto" />
        </div>

        {/* Steps indicator */}
        <div className="flex items-center justify-center gap-4 mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border transition-all ${
                  step >= s
                    ? "border-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.15)] text-[oklch(0.78_0.14_85)]"
                    : "border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.45_0.03_85)]"
                }`}
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                {s}
              </div>
              {s < 3 && <div className={`w-16 h-px ${step > s ? "bg-[oklch(0.78_0.14_85/0.5)]" : "bg-[oklch(0.78_0.14_85/0.15)]"}`} />}
            </div>
          ))}
        </div>

        {/* Step 1: Choose Tarotista */}
        {step === 1 && (
          <div>
            <h2 className="text-lg font-bold mb-6 text-center" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Paso 1: Elige tu Tarotista
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {tarotistas?.tarotistas.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSelectedTarotistaId(t.id)}
                  className={`p-4 rounded-xl border text-left transition-all duration-200 ${
                    selectedTarotistaId === t.id
                      ? "border-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.1)]"
                      : "border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)]"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-base font-bold border border-[oklch(0.78_0.14_85/0.4)] shrink-0"
                      style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 290), oklch(0.20 0.03 285))", fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>
                      {t.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)] truncate" style={{ fontFamily: "'Cinzel', serif" }}>{t.name}</div>
                      <div className="text-xs text-[oklch(0.55_0.03_85)] truncate">{t.specialty}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className={`text-xs ${t.available ? "border-green-500/30 text-green-400" : "border-red-500/30 text-red-400"}`}>
                      {t.available ? "Disponible" : "Ocupada"}
                    </Badge>
                    <span className="text-xs font-bold" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                      {parseFloat(t.pricePerSession ?? "25").toFixed(0)}€
                    </span>
                  </div>
                </button>
              ))}
            </div>
            <div className="text-center">
              <Button
                onClick={() => setStep(2)}
                disabled={!selectedTarotistaId}
                style={{
                  background: selectedTarotistaId ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))" : "oklch(0.16 0.015 285)",
                  color: selectedTarotistaId ? "oklch(0.08 0.005 285)" : "oklch(0.45 0.03 85)",
                  fontFamily: "'Cinzel', serif",
                  letterSpacing: "0.1em",
                }}
              >
                Continuar
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Date & Type */}
        {step === 2 && (
          <div className="max-w-xl mx-auto">
            <h2 className="text-lg font-bold mb-6 text-center" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Paso 2: Fecha y Tipo de Consulta
            </h2>

            {/* Consultation Type */}
            <div className="mb-6">
              <label className="block text-xs text-[oklch(0.78_0.14_85)] tracking-wider uppercase mb-3" style={{ fontFamily: "'Cinzel', serif" }}>
                Tipo de Consulta
              </label>
              <div className="grid grid-cols-3 gap-3">
                {consultationTypes.map((ct) => (
                  <button
                    key={ct.value}
                    onClick={() => setConsultationType(ct.value as "chat" | "video" | "phone")}
                    className={`p-3 rounded-lg border text-center transition-all ${
                      consultationType === ct.value
                        ? "border-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.1)]"
                        : "border-[oklch(0.78_0.14_85/0.2)] bg-[oklch(0.10_0.007_285)] hover:border-[oklch(0.78_0.14_85/0.4)]"
                    }`}
                  >
                    <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)] mb-1" style={{ fontFamily: "'Cinzel', serif", fontSize: "0.75rem" }}>{ct.label}</div>
                    <div className="text-xs text-[oklch(0.50_0.03_85)]">{ct.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div className="mb-6">
              <label className="block text-xs text-[oklch(0.78_0.14_85)] tracking-wider uppercase mb-3" style={{ fontFamily: "'Cinzel', serif" }}>
                Duración
              </label>
              <div className="flex gap-3">
                {durations.map((d) => (
                  <button
                    key={d.value}
                    onClick={() => setDuration(d.value)}
                    className={`flex-1 py-2 rounded-lg border text-sm font-semibold transition-all ${
                      duration === d.value
                        ? "border-[oklch(0.78_0.14_85)] bg-[oklch(0.78_0.14_85/0.1)] text-[oklch(0.78_0.14_85)]"
                        : "border-[oklch(0.78_0.14_85/0.2)] text-[oklch(0.60_0.03_85)] hover:border-[oklch(0.78_0.14_85/0.4)]"
                    }`}
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs text-[oklch(0.78_0.14_85)] tracking-wider uppercase mb-2" style={{ fontFamily: "'Cinzel', serif" }}>Fecha *</label>
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] focus:border-[oklch(0.78_0.14_85)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[oklch(0.78_0.14_85)] tracking-wider uppercase mb-2" style={{ fontFamily: "'Cinzel', serif" }}>Hora *</label>
                <Input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] focus:border-[oklch(0.78_0.14_85)]"
                />
              </div>
            </div>

            {/* Question */}
            <div className="mb-6">
              <label className="block text-xs text-[oklch(0.78_0.14_85)] tracking-wider uppercase mb-2" style={{ fontFamily: "'Cinzel', serif" }}>
                Tu Pregunta (opcional)
              </label>
              <Textarea
                placeholder="¿Qué deseas consultar? Cuanto más específica sea tu pregunta, mejor podrá guiarte tu tarotista..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                rows={3}
                className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] placeholder:text-[oklch(0.40_0.02_85)] focus:border-[oklch(0.78_0.14_85)]"
              />
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)} className="border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]" style={{ fontFamily: "'Cinzel', serif" }}>
                Atrás
              </Button>
              <Button
                onClick={() => setStep(3)}
                disabled={!date || !time}
                className="flex-1"
                style={{
                  background: date && time ? "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))" : "oklch(0.16 0.015 285)",
                  color: date && time ? "oklch(0.08 0.005 285)" : "oklch(0.45 0.03 85)",
                  fontFamily: "'Cinzel', serif",
                  letterSpacing: "0.1em",
                }}
              >
                Continuar
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Contact & Confirm */}
        {step === 3 && (
          <div className="max-w-xl mx-auto">
            <h2 className="text-lg font-bold mb-6 text-center" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Paso 3: Confirmar Reserva
            </h2>

            {/* Summary */}
            <div className="p-5 rounded-xl border border-[oklch(0.78_0.14_85/0.3)] bg-[oklch(0.10_0.007_285)] mb-6">
              <h3 className="text-sm font-bold mb-4" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>Resumen</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[oklch(0.60_0.03_85)]">Tarotista:</span>
                  <span className="text-[oklch(0.88_0.05_85)] font-semibold" style={{ fontFamily: "'Cinzel', serif" }}>{selectedTarotista?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[oklch(0.60_0.03_85)]">Tipo:</span>
                  <span className="text-[oklch(0.88_0.05_85)]">{consultationTypes.find((c) => c.value === consultationType)?.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[oklch(0.60_0.03_85)]">Duración:</span>
                  <span className="text-[oklch(0.88_0.05_85)]">{duration} minutos</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[oklch(0.60_0.03_85)]">Fecha:</span>
                  <span className="text-[oklch(0.88_0.05_85)]">{new Date(`${date}T${time}`).toLocaleString("es-ES", { dateStyle: "medium", timeStyle: "short" })}</span>
                </div>
                <div className="flex justify-between border-t border-[oklch(0.78_0.14_85/0.1)] pt-2 mt-2">
                  <span className="text-[oklch(0.60_0.03_85)]">Precio:</span>
                  <span className="font-bold" style={{ color: "oklch(0.78 0.14 85)", fontFamily: "'Cinzel', serif" }}>
                    {parseFloat(selectedTarotista?.pricePerSession ?? "25").toFixed(0)}€
                  </span>
                </div>
              </div>
            </div>

            {/* Guest info if not logged in */}
            {!isAuthenticated && (
              <div className="mb-6 space-y-4">
                <h3 className="text-sm font-bold" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.78 0.14 85)" }}>Tus Datos</h3>
                <div>
                  <label className="block text-xs text-[oklch(0.60_0.03_85)] mb-1">Nombre *</label>
                  <Input value={guestName} onChange={(e) => setGuestName(e.target.value)} className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] focus:border-[oklch(0.78_0.14_85)]" />
                </div>
                <div>
                  <label className="block text-xs text-[oklch(0.60_0.03_85)] mb-1">Email *</label>
                  <Input type="email" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] focus:border-[oklch(0.78_0.14_85)]" />
                </div>
                <div>
                  <label className="block text-xs text-[oklch(0.60_0.03_85)] mb-1">Teléfono</label>
                  <Input value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)} className="bg-[oklch(0.11_0.008_285)] border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.90_0.03_85)] focus:border-[oklch(0.78_0.14_85)]" />
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(2)} className="border-[oklch(0.78_0.14_85/0.3)] text-[oklch(0.78_0.14_85)] hover:bg-[oklch(0.78_0.14_85/0.1)]" style={{ fontFamily: "'Cinzel', serif" }}>
                Atrás
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={createReserva.isPending}
                className="flex-1"
                style={{
                  background: "linear-gradient(135deg, oklch(0.78 0.14 85), oklch(0.65 0.12 85))",
                  color: "oklch(0.08 0.005 285)",
                  fontFamily: "'Cinzel', serif",
                  letterSpacing: "0.1em",
                }}
              >
                <Sparkles className="w-4 h-4 mr-2" />
                {createReserva.isPending ? "Reservando..." : "Confirmar Reserva"}
              </Button>
            </div>
          </div>
        )}

        {/* My Reservations */}
        {isAuthenticated && myReservas && myReservas.length > 0 && (
          <div className="mt-16">
            <h2 className="text-xl font-bold mb-6" style={{ fontFamily: "'Cinzel', serif", color: "oklch(0.88 0.08 85)" }}>
              Mis Reservas
            </h2>
            <div className="space-y-3">
              {myReservas.map((r) => (
                <div key={r.id} className="p-4 rounded-xl border border-[oklch(0.78_0.14_85/0.15)] bg-[oklch(0.10_0.007_285)] flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold text-[oklch(0.88_0.05_85)]" style={{ fontFamily: "'Cinzel', serif" }}>
                      {new Date(r.scheduledAt).toLocaleString("es-ES", { dateStyle: "medium", timeStyle: "short" })}
                    </div>
                    <div className="text-xs text-[oklch(0.55_0.03_85)] mt-0.5">{r.consultationType} · {r.duration} min</div>
                  </div>
                  <Badge
                    variant="outline"
                    className={`text-xs ${
                      r.status === "confirmed" ? "border-green-500/40 text-green-400" :
                      r.status === "completed" ? "border-blue-500/40 text-blue-400" :
                      r.status === "cancelled" ? "border-red-500/40 text-red-400" :
                      "border-yellow-500/40 text-yellow-400"
                    }`}
                  >
                    {r.status === "pending" ? "Pendiente" : r.status === "confirmed" ? "Confirmada" : r.status === "completed" ? "Completada" : "Cancelada"}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
